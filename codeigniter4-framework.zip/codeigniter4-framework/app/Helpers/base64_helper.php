<?php

if (!function_exists('safe_base64_encode')) {
    function safe_base64_encode($string)
    {
        return rtrim(strtr(base64_encode($string), '+/', '-_'), '=');
    }
}

if (!function_exists('safe_base64_decode')) {
    function safe_base64_decode($string)
    {
        return base64_decode(strtr($string, '-_', '+/') . str_repeat('=', 3 - (3 + strlen($string)) % 4));
    }
}
