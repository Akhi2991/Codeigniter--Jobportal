<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<style>
.chat-box {
    height: 400px;
    overflow-y: auto;
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    border: 1px solid #dee2e6;
}
.message-left, .message-right {
    max-width: 75%;
    padding: 10px 15px;
    border-radius: 20px;
    margin-bottom: 10px;
    position: relative;
    word-wrap: break-word;
}
.message-left {
    background-color: #e2e3e5;
    align-self: flex-start;
    border-bottom-left-radius: 0;
}
.message-right {
    background-color: #0d6efd;
    color: white;
    align-self: flex-end;
    border-bottom-right-radius: 0;
}
.timestamp {
    font-size: 0.75rem;
    color: #6c757d;
    margin-top: 5px;
}
.chat-container {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
</style>

<div class="container mt-4">
    <h4 class="mb-3">Chat with <?= esc($senderName) ?></h4>

    <div class="chat-box d-flex flex-column mb-3" id="chatMessages">
        <?= $this->include('chat/messages_fragment') ?>
    </div>

    <form action="<?= site_url('chat/send') ?>" method="post" class="d-flex gap-2">
        <input type="hidden" name="receiver_id" value="<?= esc($senderId) ?>">
        <input type="text" name="message" class="form-control" placeholder="Type your message..." required>
        <button type="submit" class="btn btn-primary">Send</button>
    </form>
</div>

<script>
function fetchMessages() {
    fetch("<?= site_url('chat/ajaxMessages/' . $senderId) ?>")
        .then(response => response.text())
        .then(html => {
            const chatBox = document.getElementById('chatMessages');
            if (chatBox.innerHTML !== html) {
                chatBox.innerHTML = html;
                chatBox.scrollTop = chatBox.scrollHeight;
                playNotificationSound();
            }
        });
}

function playNotificationSound() {
    // const audio = new Audio("<?= base_url('assets/slick-notification.mp3') ?>");
    // audio.play();
}

setInterval(fetchMessages, 5000);
window.onload = () => {
    const chatBox = document.getElementById('chatMessages');
    chatBox.scrollTop = chatBox.scrollHeight;
};
</script>

<?= $this->endSection() ?>
