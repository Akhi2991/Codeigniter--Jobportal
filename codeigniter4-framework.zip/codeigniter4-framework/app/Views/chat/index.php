<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h4>Chat with User #<?= esc($recipient_id) ?></h4>
    <div id="chat-box" class="border rounded p-3 bg-light" style="height: 300px; overflow-y: scroll;">
        <!-- Messages will be loaded here -->
    </div>

    <form id="chat-form" class="mt-3">
    	<?php 

    	$recipient_id = session()->get('user_id'); ?>
        <input type="text" name="receiver_id" value="<?= esc($recipient_id) ?>">
        <div class="input-group">
            <input type="text" name="message" class="form-control" placeholder="Type your message..." required>
            <button type="submit" class="btn btn-primary">Send</button>
        </div>
    </form>
</div>

<script>
    const chatBox = document.getElementById('chat-box');
    const form = document.getElementById('chat-form');
    const receiverId = "<?= esc($recipient_id) ?>";

    function fetchMessages() {
        fetch('<?= site_url('chat/fetch') ?>/' + receiverId)
            .then(res => res.json())
            .then(data => {
                chatBox.innerHTML = '';
                data.forEach(msg => {
				let align = msg.sender_id == <?= session()->get('user_id') ?> ? 'text-end' : 'text-start';				chatBox.innerHTML += `<div class="${align}"><span class="badge bg-secondary">${msg.message}</span></div>`;
                });
                chatBox.scrollTop = chatBox.scrollHeight;
            });
    }

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(form);
        fetch('<?= site_url('chat/send') ?>', {
            method: 'POST',
            body: formData
        }).then(() => {
            form.reset();
            fetchMessages();
        });
    });

    setInterval(fetchMessages, 2000); // auto refresh every 2 sec
    fetchMessages(); // initial fetch

   
</script>

<?= $this->endSection() ?>
