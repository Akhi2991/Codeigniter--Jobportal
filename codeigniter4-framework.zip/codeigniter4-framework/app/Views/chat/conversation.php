<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="max-w-3xl mx-auto mt-10 p-4 bg-white shadow rounded-lg">
    <h2 class="text-xl font-semibold mb-4">💬 Chat with Employer</h2>

    <div id="chat-box" class="h-80 overflow-y-auto border rounded p-3 bg-gray-50 mb-4">
        <?php foreach ($messages as $msg): ?>
            <div class="mb-2 <?= $msg['sender_id'] == session()->get('user_id') ? 'text-right' : 'text-left' ?>">
                <div class="inline-block px-4 py-2 rounded-lg <?= $msg['sender_id'] == session()->get('user_id') ? 'bg-green-200' : 'bg-blue-200' ?>">
                    <?= esc($msg['message']) ?>
                </div>
                <div class="text-xs text-gray-400 mt-1"><?= date('d M H:i', strtotime($msg['created_at'])) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <form id="messageForm" method="post" class="flex gap-2">
        <input type="hidden" name="receiver_id" value="<?= esc($receiverId) ?>">
        <input type="text" name="job_id" value="<?= esc($jobId) ?>">
        <input type="text" name="message" class="flex-grow border rounded px-3 py-2" placeholder="Type your message..." required>
        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Send</button>
    </form>
</div><br/>

<script>
    const chatBox = document.getElementById('chat-box');
    const form = document.getElementById('messageForm');

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(form);

        fetch("<?= site_url('chat/sendMessage') ?>", {
            method: 'POST',
            body: formData
        }).then(() => {
            form.message.value = '';
            fetchMessages();
        });
    });

    function fetchMessages() {
        fetch("<?= site_url('chat/fetchMessages/' . $receiverId) ?>?job_id=<?= $jobId ?>")
            .then(response => response.json())
            .then(data => {
                chatBox.innerHTML = '';
                data.forEach(msg => {
                    const isMe = msg.sender_id == <?= session()->get('user_id') ?>;
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'mb-2 ' + (isMe ? 'text-right' : 'text-left');
                    msgDiv.innerHTML = `
                        <div class="inline-block px-4 py-2 rounded-lg ${isMe ? 'bg-green-200' : 'bg-blue-200'}">
                            ${msg.message}
                        </div>
                        <div class="text-xs text-gray-400 mt-1">${new Date(msg.created_at).toLocaleString()}</div>
                    `;
                    chatBox.appendChild(msgDiv);
                });
                chatBox.scrollTop = chatBox.scrollHeight;
            });
    }

    setInterval(fetchMessages, 3000); // Auto-refresh every 3 seconds
</script>

<?= $this->endSection() ?>
