<?php
$myId = session()->get('user_id');
?>
<?php if (!empty($messages)): ?>

<?php foreach ($messages as $msg): ?>
    <?php
        $isMine = $msg['sender_id'] == $myId;
        $senderName = $userMap[$msg['sender_id']] ?? 'User #' . $msg['sender_id'];
    ?>
    <div class="<?= $isMine ? 'message-right ms-auto' : 'message-left' ?>">
        <strong><?= $senderName ?><?= $isMine ? ' (You)' : '' ?>:</strong><br>
        <?= esc($msg['message']) ?>
        <div class="timestamp text-end" style="color:black!important;">
            <?= date('d M Y, h:i A', strtotime($msg['created_at'])) ?>
        </div>
    </div>
<?php endforeach; ?>
<?php else: ?>
    <p class="text-muted text-center">No messages yet. Start the conversation 👋</p>
<?php endif; ?>
