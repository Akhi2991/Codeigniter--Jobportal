<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h4 class="mb-4">💬 Your Chats</h4>

    <?php if(!empty($messages)): ?>
        <div class="list-group">
            <?php foreach ($messages as $msg): ?>
                <a href="<?= site_url('chat/view/' . $msg['sender_id'] . '/') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                    <div>
                        <div class="fw-bold">
                            From: User #<?= esc($msg['sender_id']) ?>
                        </div>
                        <div class="text-muted small">
                            <?= character_limiter(esc($msg['message']), 60) ?>
                        </div>
                    </div>
                    <?php if (!$msg['is_read']): ?>
                        <span class="badge bg-warning text-dark">Unread</span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            No messages found.
        </div>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
