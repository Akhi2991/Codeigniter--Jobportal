<table class="table table-bordered">
    <thead>
        <tr>
            <th>Logo</th>
            <th>Name</th>
            <th>Location</th>
            <th>Industry</th>
            <th>Job Count</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($companies as $company): ?>
        <tr>
            <td><img src="<?= base_url('uploads/companies/' . $company['logo']) ?>" width="50"></td>
            <td><?= esc($company['name']) ?></td>
            <td><?= esc($company['location']) ?></td>
            <td><?= esc($company['industry']) ?></td>
            <td><?= esc($company['job_count']) ?></td>
            <td>
                <a href="<?= site_url('admin/companies/edit/' . $company['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="<?= site_url('admin/companies/delete/' . $company['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<!-- Pagination -->
<?= $pager->links() ?>