<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<h2>Companies</h2>
<a href="<?= site_url('admin/companies/create') ?>" class="btn btn-primary mb-3">Add Company</a>

<?php if (session()->getFlashdata('success')): ?>
<div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

  <!-- Search Box -->
    <div class="input-group mb-3">
        <input type="text" id="searchKeyword" class="form-control" placeholder="Search companies...">
        <button class="btn btn-primary" onclick="loadCompanies()">🔍 Search</button>
    </div>

    <!-- Company List Table -->
    <div id="companyList">
        <?= view('admin/companies/list_partial', ['companies' => $companies, 'pager' => $pager]) ?>
    </div>
<script>
function loadCompanies(page = 1) {
    const keyword = document.getElementById('searchKeyword').value;
    //alert(keyword);

    fetch(`<?= site_url('admin/companies/search') ?>?page=${page}&keyword=${encodeURIComponent(keyword)}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(res => res.text())
    .then(data => {
        document.getElementById('companyList').innerHTML = data;
    });
}

// Handle pagination clicks
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('page-link')) {
        e.preventDefault();
        const url = new URL(e.target.href);
        const page = url.searchParams.get('page');
        loadCompanies(page);
    }
});
</script>

<?= $this->endSection() ?>
