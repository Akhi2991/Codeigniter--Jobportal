<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h3 class="mb-4">✏️ Edit Company - <?= esc($company['name']) ?></h3>

    <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach (session('errors') as $err): ?>
                    <li><?= esc($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('admin/companies/update/' . $company['id']) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label class="form-label">Company Name</label>
            <input type="text" name="name" value="<?= esc($company['name']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="location" value="<?= esc($company['location']) ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Industry</label>
            <input type="text" name="industry" value="<?= esc($company['industry']) ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Job Count</label>
            <input type="number" name="job_count" value="<?= esc($company['job_count']) ?>" class="form-control" min="0">
        </div>

        <div class="mb-3">
            <label class="form-label">Current Logo</label><br/>
            <?php if ($company['logo']): ?>
                <img src="<?= base_url('uploads/companies/' . $company['logo']) ?>" width="100">
            <?php else: ?>
                <p class="text-muted">No logo uploaded.</p>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Change Logo (optional)</label>
            <input type="file" name="logo" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Update Company</button>
        <a href="<?= site_url('admin/companies') ?>" class="btn btn-secondary">Back</a>
    </form>
</div>

<?= $this->endSection() ?>
