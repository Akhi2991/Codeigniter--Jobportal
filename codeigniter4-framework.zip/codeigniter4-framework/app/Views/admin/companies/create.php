<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h3 class="mb-4">➕ Add New Company</h3>

    <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach (session('errors') as $err): ?>
                    <li><?= esc($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('admin/companies/store') ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label class="form-label">Company Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="location" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Industry</label>
            <input type="text" name="industry" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Job Count</label>
            <input type="number" name="job_count" class="form-control" min="0" value="0">
        </div>

        <div class="mb-3">
            <label class="form-label">Company Logo</label>
            <input type="file" name="logo" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success">Create Company</button>
        <a href="<?= site_url('admin/companies') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?= $this->endSection() ?>
