<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h3 class="mb-3">👥 Manage Users</h3>

    <form method="get" class="mb-3">
        <select name="role" class="form-select w-auto d-inline-block">
            <option value="">All Roles</option>
            <option value="user" <?= $selectedRole === 'user' ? 'selected' : '' ?>>Job Seekers</option>
            <option value="employer" <?= $selectedRole === 'employer' ? 'selected' : '' ?>>Employers</option>
        </select>
        <button type="submit" class="btn btn-sm btn-secondary">Filter</button>
    </form>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php elseif (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover">
        <thead class="table-light">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Registered</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($users): ?>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= esc($user['name']) ?></td>
                    <td><?= esc($user['email']) ?></td>
                    <td><?= ucfirst(esc($user['role'])) ?></td>
                    <td><?= date('d M Y', strtotime($user['created_at'] ?? 'now')) ?></td>
                    <td>
                        <a href="<?= site_url('admin/users/delete/' . $user['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="5">No users found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
