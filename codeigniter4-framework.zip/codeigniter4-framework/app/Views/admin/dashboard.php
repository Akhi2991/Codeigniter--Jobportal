<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h2>Welcome, <?= session('admin_name') ?>!</h2>
    <p>This is your Admin Dashboard.</p>

    <div class="row mt-4">
        <div class="col-md-4">
            <a href="<?= site_url('admin/users') ?>" class="btn btn-outline-primary w-100">Manage Users</a>
        </div>
        <div class="col-md-4">
            <a href="<?= site_url('admin/jobs') ?>" class="btn btn-outline-success w-100">Manage Jobs</a>
        </div>
        <div class="col-md-4">
            <a href="<?= site_url('admin/applications') ?>" class="btn btn-outline-info w-100">View Applications</a>
        </div>
    </div>
</div>
<div class="container mt-4">
    <h3 class="mb-4">📊 Application Statistics</h3>

    <div class="row">
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">This Week</h5>
                    <p class="card-text display-6"><?= esc($weekly) ?> Applications</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">This Month</h5>
                    <p class="card-text display-6"><?= esc($monthly) ?> Applications</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-dark mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Applications</h5>
                    <p class="card-text display-6"><?= esc($total) ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container mt-5">
    <h3 class="mb-4">📊 Weekly Applications Overview</h3>

    <canvas id="appChart" height="100"></canvas>
</div><br/>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('appChart').getContext('2d');

    const appChart = new Chart(ctx, {
        type: 'bar', // change to 'line' for a line chart
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                label: 'Applications per Day',
                data: <?= json_encode($dataPoints) ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                tension: 0.3
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
</script>

<?= $this->endSection() ?>
