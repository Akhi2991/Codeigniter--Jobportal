<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h3 class="mb-4">📄 Manage Job Applications</h3>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php elseif(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Applicant</th>
                <th>Email</th>
                <th>Job</th>
                <th>Resume</th>
                <th>Status</th>
                <th>Applied On</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($applications): ?>
            <?php foreach ($applications as $app): ?>
                <tr>
                    <td><?= esc($app['applicant_name']) ?></td>
                    <td><?= esc($app['email']) ?></td>
                    <td><?= esc($app['job_title']) ?></td>
                    <td>
                        <?php if (!empty($app['resume'])): ?>
                            <a href="<?= base_url('uploads/resumes/' . $app['resume']) ?>" target="_blank">View</a>
                        <?php else: ?>
                            <em>No resume</em>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge bg-info"><?= esc($app['status']) ?></span></td>
                    <td><?= date('d M Y', strtotime($app['created_at'])) ?></td>
                    <td>
                        <a href="<?= site_url('admin/applications/delete/' . $app['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this application?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7" class="text-center">No applications found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
