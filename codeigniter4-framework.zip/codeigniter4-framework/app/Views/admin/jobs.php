<?= $this->extend('layouts/adminbase') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h3 class="mb-4">📋 Manage All Posted Jobs</h3>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php elseif(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Title</th>
                <th>Employer</th>
                <th>Location</th>
                <th>Salary</th>
                <th>Posted</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($jobs): ?>
            <?php foreach ($jobs as $job): ?>
                <tr>
                    <td><?= esc($job['title']) ?></td>
                    <td><?= esc($job['employer_name']) ?></td>
                    <td><?= esc($job['location']) ?></td>
                    <td><?= esc($job['salary']) ?></td>
                    <td><?= date('d M Y', strtotime($job['created_at'])) ?></td>
                    <td>
                        <a href="<?= site_url('admin/jobs/delete/' . $job['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="6">No jobs found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
