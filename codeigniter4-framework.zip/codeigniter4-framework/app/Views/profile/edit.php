<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>
<style type="text/css">
.rounded-circle {
    object-fit: cover;
    border: 2px solid #ddd;
}  
</style>


<div class="container mt-5" style="max-width: 700px;">
     <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id')))  ?>">⬅ Back to Dashboard</a>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <h3 class="mb-4 text-center text-primary">👤 Edit Profile</h3>

            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php elseif(session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <form method="post" action="<?= site_url('profile/update') ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?= esc($user['name']) ?>" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" value="<?= esc($user['email']) ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone (Optional)</label>
                    <input type="text" name="phone" class="form-control" value="<?= esc($user['phone'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label for="bio" class="form-label">Short Bio</label>
                    <textarea name="bio" class="form-control" rows="3"><?= esc($user['bio'] ?? '') ?></textarea>
                </div>
                <div class="mb-3 text-center">
                    <label for="drop-zone" class="form-label">Profile Picture</label>
                    <div id="drop-zone" class="border p-4 rounded bg-light text-muted" style="cursor: pointer;">
                        <p>Drag & Drop your image here or click to select</p>
                        <input type="file" name="profile_image" id="file-input" class="d-none" accept="image/*">
                        <img id="preview" src="<?= base_url('uploads/profile_pics/' . (!empty($user['profile_pic']) ? $user['profile_pic'] : 'default.png')) ?>" 
                             class="mt-3 rounded-circle border" width="120" height="120" style="object-fit: cover; display:block; margin:auto;">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">💾 Save Changes</button>
            </form>
        </div>
    </div>
</div><br/><br/>

<?= $this->endSection() ?>
