<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
   <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;"> 
    <h3 class="mb-0">👤 My Profile</h3>
  </div>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <div class="card p-3">
        <?php if ($user['profile_pic']): ?>
            <img src="<?= base_url('uploads/profile_pics/' . $user['profile_pic']) ?>" width="100" class="mb-3 rounded-circle">
        <?php endif; ?>

        <p><strong>Name:</strong> <?= esc($user['name']) ?></p>
        <p><strong>Email:</strong> <?= esc($user['email']) ?></p>
        <p><strong>Phone:</strong> <?= esc($user['phone']) ?></p>
        <p><strong>Bio:</strong> <?= esc($user['bio']) ?></p>

        <a href="<?= site_url('profile/edit') ?>" class="btn btn-primary">Edit Profile</a>
    </div>
</div>
<?= $this->endSection() ?>
