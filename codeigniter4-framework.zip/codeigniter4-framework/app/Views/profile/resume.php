<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <div class="card shadow rounded-4 p-4">
        <h3 class="mb-4 text-primary">📄 My Resume</h3>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?= esc($error) ?></div>
        <?php endif; ?>

        <div class="mb-4">
            <?php if ($user['resume']): ?>
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="bi bi-file-earmark-text fs-1 text-secondary"></i>
                    </div>
                    <div>
                        <p class="mb-1"><strong>Current Resume:</strong></p>
                        <a href="<?= base_url('uploads/resumes/' . $user['resume']) ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-eye"></i> View Resume
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-muted">No resume uploaded yet.</p>
            <?php endif; ?>
        </div>

        <form method="post" enctype="multipart/form-data" action="<?= site_url('profile/replaceresume') ?>">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label"><strong>Upload New Resume (PDF, DOC)</strong></label>
                <input type="file" name="resume" accept=".pdf,.doc,.docx" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-upload"></i> Upload New Resume
            </button>
        </form>
    </div>
</div>

<?= $this->endSection() ?>
