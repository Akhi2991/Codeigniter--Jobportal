<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Job Portal</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/aos.css" rel="stylesheet">
    <link href="assets/css/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

    <!-- OwlCarousel JS -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script>
    function validateForm() {
    var response = grecaptcha.getResponse();
    if (response.length == 0) {
        // reCAPTCHA challenge not completed
        alert('Please complete the CAPTCHA challenge.');
        return false; // Prevent form submission
    }
    // reCAPTCHA challenge completed
    return true; // Allow form submission
}
    </script>
</head>
<body  style="background-image: url('<?= base_url('uploads/career-employment-occupation-recruitment-work-concept.jpg') ?>');
             background-size: cover;
             background-repeat: no-repeat;
         ">
  <!-- ✅ Loader -->
<?php if (uri_string() === 'jobportal'): ?>
<div id="loader">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<?php endif; ?>
  <!-- ✅ Public Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="<?= site_url('/jobportal') ?>">Job Portal</a>

    <!-- 🔹 Toggler for small screens only -->
    <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- 🔹 Regular navbar for large screens -->
    <div class="collapse navbar-collapse d-none d-lg-block">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link nav-animate" href="<?= site_url('/jobportal') ?>">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-animate" href="<?= site_url('jobs') ?>">Browse Jobs</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-animate" href="<?= site_url('auth/login') ?>">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-animate" href="<?= site_url('auth/register') ?>">Register</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- 🔹 Offcanvas menu (for mobile) -->
<div class="offcanvas offcanvas-start bg-dark text-white" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="mobileSidebarLabel">Menu</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <ul class="nav flex-column">
      <li class="nav-item"><a class="nav-link text-white" href="<?= site_url('/jobportal') ?>">🏠 Home</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="<?= site_url('jobs') ?>">🔍 Browse Jobs</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="<?= site_url('auth/login') ?>">🔐 Login</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="<?= site_url('auth/register') ?>">📝 Register</a></li>
    </ul>
  </div>
</div>


<?= $this->renderSection('content') ?>
<?= view('layouts/footer') ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
 window.addEventListener('load', function () {
      const loader = document.getElementById('loader');
      if (loader) {
          loader.classList.add('hidden');
          setTimeout(() => loader.remove(), 3000);
      }
  });
 document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.onclick = function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    };
  });

 let lastScrollTop = 0;
const navbar = document.querySelector('nav.navbar');

window.addEventListener("scroll", function() {
    const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
    if (currentScroll > lastScrollTop) {
        // Scrolling down
        navbar.style.top = "-80px"; // hide navbar
    } else {
        // Scrolling up
        navbar.style.top = "0";
    }
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
});
window.addEventListener('scroll', function () {
    const navbar = document.querySelector('nav.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

 $(document).ready(function(){
    $('.owl-carousel').owlCarousel({
      loop: false,
      margin: 15,
      autoplay: true,
      autoplayTimeout: 3000,
      autoplayHoverPause: true,
      nav: true,
      dots: true,
      responsive:{
        0:{ items:1 },
        600:{ items:2 },
        1000:{ items:3 }
      }
    });

  /*$('.owl-carousel').owlCarousel({
    items: 5,          // or adjust dynamically
    loop: false,       // no cloning
    margin: 20,
    nav: true,
    dots: true
});*/


     $('.top-companies-slider').owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 600,
        responsive:{
            0:{ items:2 },
            600:{ items:3 },
            1000:{ items:5 }
        }
    });

    AOS.init({ duration: 1000 });
  });
</script>
<script>
   AOS.init({
    once: true, // animation happens only once
    duration: 1000 // animation duration in ms
  });
</script>

</body>
    <?= $this->renderSection('custom_js') ?>
</html>