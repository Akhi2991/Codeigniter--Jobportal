<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel - <?= esc($title ?? 'Dashboard') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <span><a class="navbar-brand" href="<?= site_url('admin/dashboard/' . base64_encode(session('admin_id'))) ?>">Admin Panel</a></span>
        <div class="ms-auto">
            <?php if (session()->get('isAdminLoggedIn')): ?>
                <a href="<?= site_url('admin/companies') ?>" class="btn btn-outline-light btn-sm"> Manage Companies</a>
                <a href="<?= site_url('admin/logout') ?>" class="btn btn-outline-light btn-sm">Logout</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="container" style="max-height:100%!important;">
    <?= $this->renderSection('content') ?>
</div>
 <?= view('layouts/footer') ?>
</body>
</html>
