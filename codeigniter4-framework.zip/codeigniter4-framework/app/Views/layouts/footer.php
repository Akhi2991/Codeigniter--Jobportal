<footer class="bg-dark text-light py-4 mt-auto">
    <div class="container text-center">
        <p class="mb-1">&copy; <?= date('Y') ?> Job Portal. All rights reserved.</p>
        <p class="mb-0">
            <a href="<?= site_url('/') ?>" class="text-light text-decoration-none me-3">Home</a>
            <a href="<?= site_url('jobs') ?>" class="text-light text-decoration-none me-3">Jobs</a>
            <a href="<?= site_url('auth/login') ?>" class="text-light text-decoration-none">Login</a>
        </p>
    </div>
</footer>
