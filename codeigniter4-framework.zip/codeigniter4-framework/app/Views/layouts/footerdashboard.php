<footer class="bg-dark text-light py-4 mt-auto">
    <div class="container text-center">
        <p class="mb-1">&copy; <?= date('Y') ?> Job Portal. All rights reserved.</p>
        <p class="mb-0">
            <a href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id'))) ?>" class="text-light text-decoration-none me-3">Home</a>
             <?php $user=session()->get(); 
                 if($user['user_role']==='user'):
                ?>
            <a href="<?= site_url('jobs') ?>" class="text-light text-decoration-none me-3">Jobs</a>
        <?php else: ?>
            <a href="<?= site_url('jobs/manage') ?>" class="text-light text-decoration-none me-3">Jobs</a>
        <?php endif; ?>
        </p>
    </div>
</footer>
