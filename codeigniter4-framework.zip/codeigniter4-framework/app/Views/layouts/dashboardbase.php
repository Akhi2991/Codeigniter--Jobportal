<!DOCTYPE html>
<html>
<head>
    <title><?= esc($title ?? 'Job Portal') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- ✅ Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
    <!-- ✅ Bootstrap Bundle JS (includes Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>
<style>
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #222;
            color: #ccc;
            text-align: center;
            padding: 10px 0;
        }
        .p-3{
            padding:3rem!important;
        }
           .navbar-blue {
            background-color: #007BFF !important; /* Hot Blue */
        }
        .navbar-blue .navbar-brand,
        .navbar-blue .nav-link,
        .navbar-blue .navbar-text {
            color: white !important;
        }
        .btn-sm{
              --bs-btn-padding-y: 14px!important;
              --bs-btn-padding-x: 18px!important;
        }
    </style>
</head>
<body style="background-image: url('<?= base_url('uploads/istockphoto-1866121862-612x612.jpg') ?>');
             background-size: cover;
             background-repeat: no-repeat;
         ">
 <?php if (session()->get('isLoggedIn')): ?>
<!-- ✅ Header with Logout -->
<nav class="navbar navbar-expand-lg navbar-blue">
    <div class="container-fluid">
       <a class="navbar-brand" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id'))) ?>">Job Portal</a>

      <?php $notifModel = new \App\Models\NotificationModel();
$userId = session()->get('user_id');

// Fetch latest 5
$notifications = $notifModel->where('user_id', $userId)
                            ->orderBy('created_at', 'DESC')
                            ->findAll();

// Count unread
$unreadCount = $notifModel->where('user_id', $userId)
                          ->where('is_read', 0)
                          ->countAllResults();
                         // print_r($unreadCount);
$messageModel = new \App\Models\MessageModel();
$userId = session()->get('user_id');

$data['unreadCount'] = $messageModel
    ->where('receiver_id', $userId)
    ->where('is_read', 0)
    ->countAllResults();
//print_r($data['unreadCount']);

?>
<div class="d-flex ms-auto">
<div class="dropdown  mx-2">
<button class="btn btn-sm btn-warning dropdown-toggle position-relative" data-bs-toggle="dropdown">
    🔔
    <?php if ($unreadCount > 0): ?>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
            <?= $unreadCount ?>
        </span>
    <?php endif; ?>
</button>
<ul class="dropdown-menu dropdown-menu-end">

    <?php if (count($notifications) > 0): ?>
        <?php foreach ($notifications as $n): ?>
            <li>
                <a class="dropdown-item" href="<?= site_url('notification/read/' . $n['id']) ?>">
                    <?= esc($n['message']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    <?php else: ?>
        <li><span class="dropdown-item text-muted">You have no notifications.</span></li>
    <?php endif; ?>
</ul>

</div>

 <!-- ✅ Chat Button -->
   <!-- <a href="<?php site_url('chat') ?>" class="btn btn-sm btn-info">💬 Chat    <span id="chat-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="display:none"></span></a>-->
   <?php $session = session();
    $userrole = $session->get('user_role'); if(($userrole)== 'user'): ?>
   <a href="<?= site_url('chat/inbox') ?>" class="btn btn-sm btn-info">
    💬 Messages
    <?php if (!empty($unreadCount)): ?>
        <span id="chat-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" >
            <?= $unreadCount ?>
        </span>
    <?php endif; ?>
</a>
<?php endif; ?>
<a href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id'))) ?>" class="btn btn-outline-light btn-sm mx-2">Home</a>
                <?php $user=session()->get(); 
                 if($user['user_role']==='user'):
                ?>
                
                <a href="<?= site_url('jobs') ?>" class="btn btn-outline-light btn-sm mx-2">🔍 Browse Jobs</a>

<button id="dropdownHoverButton" data-dropdown-toggle="dropdownHover" data-dropdown-trigger="hover" class="btn btn-outline-light btn-sm mx-2" type="button">My Jobs <svg class="w-2.5 h-2.5 ms-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
</svg>
</button>
<!-- Dropdown menu -->
<div id="dropdownHover" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow-sm w-44 dark:bg-gray-700">
    <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownHoverButton">
      <li>
         <a href="<?= site_url('jobs/AppliedJobs') ?>" class="btn btn-outline-light btn-sm mx-2" style="--bs-btn-color: #white!important;">Applied Jobs</a>
     </li>
      <li>
        <a href="<?= site_url('jobs/saved') ?>" class="btn btn-outline-light btn-sm mx-2" style="--bs-btn-color: #white!important;">  Saved Jobs</a>
      </li>
            <li>
        <a href="<?= site_url('jobs/archieved') ?>" class="btn btn-outline-light btn-sm mx-2" style="--bs-btn-color: #white!important;">  Archieved Jobs</a>
      </li>
    </ul>
</div>
<?php else: ?>

                <a href="<?= site_url('jobs/postjobs') ?>" class="btn btn-outline-light btn-sm mx-2">➕ Post a Job</a>    

                <a href="<?= site_url('jobs/manage') ?>" class="btn btn-outline-light btn-sm mx-2">Manage Jobs</a>

                
                <a href="<?= site_url('jobs/applicants') ?>" class="btn btn-outline-light btn-sm mx-2">👥 View Applicants</a>
               

                <?php endif; ?>

            <!-- Navbar Right Dropdown -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" title="<?= esc(session('user_name')) ?>">
                        <!-- Profile picture (circle image) -->
                        <?php if(session('user_profile')): ?>
                       <img src="<?= base_url('uploads/profile_pics/' . session('user_profile')) ?>" class="rounded-circle" width="32" height="32" style="object-fit: cover; border: 2px solid #fff;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?= esc(session('user_name')) ?>">
                    <?php else: ?>
                         <img src="<?= base_url('uploads/profile_pics/default.png') ?>" class="rounded-circle" width="32" height="32" style="object-fit: cover; border: 2px solid #fff;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?= esc(session('user_name')) ?>">
                    <?php endif; ?>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text text-muted"><i class="bi bi-person-circle"></i> <?= esc(session('user_name')) ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= site_url('profile') ?>">👤 Profile</a></li>
                        <li><a class="dropdown-item text-danger" href="<?= site_url('auth/logout') ?>">🚪 Logout</a></li>
                    </ul>
                </li>
            </ul>

            <?php endif; ?>
        </div>
    </div>
</nav>
<!-- Content -->
<div class="container-fluid">
     <?php if(session()->getFlashdata('error')): ?>
                 <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>
    <?= $this->renderSection('content') ?>
</div>
 <?= view('layouts/footerdashboard') ?>


<script type="text/javascript">
 /*function checkUnreadChatCount() {
    fetch("<?= site_url('chat/unread-count') ?>")
        .then(res => res.json())
        .then(data => {
            const badge = document.getElementById('chat-badge');
            if (data.count > 0) {
                badge.innerText = data.count;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        });
}

setInterval(checkUnreadChatCount, 5000);
checkUnreadChatCount();*/

    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const preview = document.getElementById('preview');

    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', e => {
        e.preventDefault();
        dropZone.classList.add('bg-secondary', 'text-white');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('bg-secondary', 'text-white');
    });

    dropZone.addEventListener('drop', e => {
        e.preventDefault();
        dropZone.classList.remove('bg-secondary', 'text-white');
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            fileInput.files = e.dataTransfer.files;
            previewFile(file);
        }
    });

    fileInput.addEventListener('change', e => {
        const file = e.target.files[0];
        if (file && file.type.startsWith('image/')) {
            previewFile(file);
        }
    });

    function previewFile(file) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.onclick = function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  };
});

 document.addEventListener("DOMContentLoaded", function () {
      var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
      tooltipTriggerList.forEach(function (tooltipTriggerEl) {
          new bootstrap.Tooltip(tooltipTriggerEl);
      });
  });

</script>
</body>
</html>
