<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5 text-center">
    <!-- Dashboard Header -->
    <div class="bg-primary text-white rounded shadow-sm p-4 mb-4">
        <h2 class="mb-0">👋 Welcome, <?= esc($user['user_name']) ?>!</h2>
    </div>

    <?php if ($user['user_role'] === 'employer'): ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <!-- Expiring Jobs Alert -->
        <?php if (!empty($expiringJobs)): ?>
            <div class="alert alert-warning shadow-sm">
                <h5><i class="bi bi-exclamation-triangle-fill text-danger"></i> Jobs Expiring Soon</h5>
                <ul class="list-unstyled">
                    <?php foreach ($expiringJobs as $job): ?>
                        <li class="mb-2">
                            <strong><?= esc($job['title']) ?></strong>
                            <span class="badge bg-danger ms-2">Expires on <?= date('d M Y', strtotime($job['expires_at'])) ?></span><br>
                            <a href="<?= site_url('jobs/edit/' . $job['id']) ?>" class="btn btn-sm btn-outline-warning mt-2">✏ Edit</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Employer Panel -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h4 class="text-primary">🏢 Employer Dashboard</h4>
                <p class="text-muted">Post and manage jobs, and track applicants.</p>
                <div class="d-grid gap-3 d-md-flex justify-content-center mt-3">
                    <a href="<?= site_url('jobs/postjobs') ?>" class="btn btn-outline-primary">➕ Post a Job</a>
                    <a href="<?= site_url('jobs/manage') ?>" class="btn btn-outline-dark">🗂 Manage Jobs</a>
                    <a href="<?= site_url('jobs/applicants') ?>" class="btn btn-outline-info">👥 View Applicants</a>
                </div>
            </div>
        </div>

    <?php else: ?>
        <!-- Job Seeker Panel -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h4 class="text-success">🎯 Job Seeker Dashboard</h4>
                <p class="text-muted">Browse job listings and manage your applications.</p>
                <div class="d-grid gap-3 d-md-flex justify-content-center mt-3">
                    <a href="<?= site_url('jobs') ?>" class="btn btn-outline-primary">🔍 Browse Jobs</a>
                    <a href="<?= site_url('applications') ?>" class="btn btn-outline-dark">📄 My Applications</a>
                    <a href="<?= site_url('profile/resume') ?>" class="btn btn-outline-info">📎 Manage Resume</a>
                    <a href="<?= site_url('jobalert/subscribe') ?>" class="btn btn-outline-success">
                        🔔 Subscribe for Job Alerts
                    </a>

                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
