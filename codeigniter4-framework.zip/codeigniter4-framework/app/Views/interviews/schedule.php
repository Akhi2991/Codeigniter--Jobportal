<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>
<div class="container mt-4" style="max-width: 600px;">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">📅 Schedule Interview</h5>
        </div>
        <div class="card-body">
             <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
             <?php endif; ?>
            <form method="post" action="<?= site_url('job/schedule') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="job_id" value="<?= $job_id ?>">
                <input type="hidden" name="applicant_id" value="<?= $applicant_id ?>">

                <div class="mb-3">
                    <label for="interview_datetime" class="form-label">📆 Date & Time</label>
                    <input type="datetime-local" id="interview_datetime" name="interview_datetime" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="mode" class="form-label">🧭 Interview Mode</label>
                    <select id="mode" name="mode" class="form-select">
                        <option value="online">Online (Zoom, Meet, etc.)</option>
                        <option value="offline">Offline (In-person)</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="location" class="form-label">📍 Location / Meeting Link</label>
                    <input type="text" id="location" name="location" class="form-control" placeholder="Enter link or address">
                </div>

                <div class="mb-3">
                    <label for="notes" class="form-label">📝 Additional Notes</label>
                    <textarea id="notes" name="notes" class="form-control" rows="3" placeholder="Optional message or instructions"></textarea>
                </div>

                <div class="d-grid">
                    <button class="btn btn-primary">✅ Schedule Interview</button>
                </div>
            </form>
        </div>
    </div>
</div>
<br/><br/>
<?= $this->endSection() ?>
