<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5" style="max-width: 850px;">
     <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id')))  ?>">
            <i class="bi bi-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body" style="max-height: 500px; overflow-y: auto;">
            <h3 class="text-primary text-center mb-4">📄 My Applications</h3>

            <?php if ($applications): ?>
                <div class="list-group" >
                    <?php foreach ($applications as $app): ?>
                        <div class="list-group-item list-group-item-action mb-2 rounded shadow-sm">
                            <h5 class="mb-1"><?= esc($app['title']) ?> <span class="badge bg-secondary"><?= esc($app['location']) ?></span></h5>
                            <small class="text-muted">📅 Applied on <?= date('d M Y', strtotime($app['created_at'])) ?></small>
                            <p class="mt-2 mb-2"><?= esc($app['coverletter']) ?></p>
                            <span class="badge bg-info text-dark">Status: <?= esc($app['status']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center">You haven't applied to any jobs yet.</div>
            <?php endif; ?>
        </div>
    </div>
</div><br/><br/>

<?= $this->endSection() ?>
