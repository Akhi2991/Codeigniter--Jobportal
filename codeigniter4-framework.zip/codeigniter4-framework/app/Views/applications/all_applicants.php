<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
        <h3 class="text-primary">All Applicants</h3>
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id')))  ?>">
            <i class="bi bi-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <?php if ($applicants): ?>
        <div class="list-group" style="max-height: 500px; overflow-y: auto;">
            <?php foreach ($applicants as $app): ?>
                <div class="list-group-item bg-light mb-3 rounded shadow-sm">
                    <form method="post" action="<?= site_url('applications/update-status/' . $app['id']) ?>">
                        <div class="mb-2">
                            <h5 class="mb-1 text-dark"><?= esc($app['name']) ?> <small class="text-muted">(<?= esc($app['email']) ?>)</small></h5>
                            <p class="mb-1"><strong>Job:</strong> <?= esc($app['title']) ?></p>
                            <p class="mb-1"><strong>Cover Letter:</strong> <br><?= esc($app['coverletter']) ?></p>
                            <p class="text-muted">Applied on <?= date('d M Y', strtotime($app['created_at'])) ?></p>
                             <p class="mb-1"><strong>Job Status:</strong> 
                                 <?php if ($app['deleted_at']): ?>
                                    <span class="badge bg-secondary">Withdrawn</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Active</span>
                                <?php endif; ?>
                             </p>
                           </div>
                        <?php if ($app['resume']): ?>
                            <a href="<?= base_url('uploads/resumes/' . $app['resume']) ?>" target="_blank" class="btn btn-outline-primary btn-sm mb-2">
                                <i class="bi bi-file-earmark-arrow-down"></i> Download Resume
                            </a>
                        <?php else: ?>
                            <p class="text-danger mb-2">No resume uploaded.</p>
                        <?php endif; ?>

                        <div class="row g-2 align-items-center">
                            <div class="col-auto">
                                <label for="status" class="form-label fw-bold mb-0">Status:</label>
                            </div>
                            <div class="col-auto">
                                <select name="status" class="form-select form-select-sm">
                                    <?php foreach (['Pending', 'Shortlisted', 'Rejected', 'Hired'] as $status): ?>
                                        <option value="<?= $status ?>" <?= $status === $app['status'] ? 'selected' : '' ?>>
                                            <?= $status ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary btn-sm" type="submit">
                                    <i class="bi bi-check2-circle"></i> Update
                                </button>
                            </div>
                            <div class="col-auto">
                                 <!-- Only show schedule button if status is 'Pending' or 'Hired' -->
                            <?php if (in_array($app['status'], ['Pending', 'Hired'])): ?>
                                <a href="<?= site_url('job/interview/' . $app['job_id'] . '/' . $app['user_id']) ?>" class="btn btn-sm btn-primary">
                                    📅 Schedule Interview
                                </a>
                            <?php endif; ?>
                            </div>
                           <div class="col-auto">
                            <?php 
                            $notifModel = new \App\Models\NotificationModel();
                            $userId = session()->get('user_id');

                            // Fetch latest notifications
                            $notifications = $notifModel->where('user_id', $userId)
                                                        ->orderBy('created_at', 'DESC')
                                                        ->findAll();

                            // Count unread notifications
                            $unreadNotifCount = $notifModel->where('user_id', $userId)
                                                           ->where('is_read', 0)
                                                           ->countAllResults();

                            // Count unread chat messages
                            $messageModel = new \App\Models\MessageModel();
                            $receiverId=$app['user_id'];
                            $unreadChatCount = $messageModel
                                 ->where("(sender_id = $receiverId AND receiver_id = $userId AND is_read= 0)")->orderBy('id', 'ASC')->countAllResults();
                           // echo  $messageModel->getLastQuery(); exit;
                            ?>

                            <a href="<?= site_url('chat/view/' . $app['user_id']) ?>" class="btn btn-sm btn-success">
                                💬 Chat 
                                <?php if ($unreadChatCount > 0): ?>
                                    <span class="badge bg-danger"><?= $unreadChatCount ?></span>
                                <?php endif; ?>
                            </a>
                        </div>

                        </div>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">No applications received for your jobs yet.</div>
    <?php endif; ?>
</div><br/><br/>
<?= $this->endSection() ?>
