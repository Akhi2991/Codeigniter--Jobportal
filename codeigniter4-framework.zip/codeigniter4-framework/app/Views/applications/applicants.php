<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <?php if(session()->getFlashdata('success')): ?>
                 <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <h3>Applicants</h3>
    <?php if ($applicants): ?>
        <ul class="list-group">
            <?php foreach ($applicants as $app): ?>
                <li class="list-group-item">
                    <strong><?= esc($app['name']) ?></strong> (<?= esc($app['email']) ?>)<br>
                    <small><?= esc($app['cover_letter']) ?></small><br>
                    Applied on <?= date('d M Y', strtotime($app['created_at'])) ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No applicants for this job yet.</p>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
