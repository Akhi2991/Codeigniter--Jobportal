<?= $this->extend('layouts/base') ?>
<?= $this->section('content') ?>

<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="card shadow-lg p-4 w-100" style="max-width: 420px;">
        <h3 class="text-center mb-3">🔐 Forgot Password</h3>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success" id="successMessage"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger" id="dangerMessage"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <form method="post" action="<?= site_url('forgot-password') ?>">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label for="email" class="form-label">📧 Email Address</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Send OTP</button>
            </div>
        </form>

        <div class="text-center mt-3">
            <a href="<?= site_url('auth/login') ?>" class="text-decoration-none">← Back to Login</a>
        </div>
    </div>
</div>
<script>
$(document).ready(function () {
    // Fade out success alert after 3 seconds
    $("#successMessage").delay(3000).fadeOut(500);
    $("#dangerMessage").delay(3000).fadeOut(500);

});
</script>

<?= $this->endSection() ?>
