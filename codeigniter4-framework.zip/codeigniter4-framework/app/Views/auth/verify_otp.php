<?= $this->extend('layouts/base') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h3>Enter OTP</h3>
    <form method="post" action="<?= site_url('auth/verify-otp') ?>">
        <input type="hidden" name="phone" value="<?= esc($phone) ?>">
        <div class="mb-3">
            <label>OTP</label>
            <input type="text" name="otp" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Verify & Login</button>
    </form>
</div>

<?= $this->endSection() ?>
