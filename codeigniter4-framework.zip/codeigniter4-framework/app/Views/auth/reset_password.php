<?= $this->extend('layouts/base') ?>
<?= $this->section('content') ?>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="card shadow-lg p-4 w-100" style="max-width: 420px;">
     <?php if(session()->getFlashdata('success')): ?>
      <div class="alert alert-success" id="successMessage"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger" id="dangerMessage"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>
    <h3>Reset Password</h3>
    <form method="post" action="<?= site_url('update-password') ?>">
            <?= csrf_field() ?>
        <input type="hidden" name="email" value="<?= esc($email) ?>">
        <div class="mb-2">
            <input type="text" name="otp" class="form-control" placeholder="Enter OTP" required>
             <small id="countdown" class="text-muted">OTP will expire in 5 minutes.</small>
        </div>
        <div class="mb-2">
            <input type="password" name="password" class="form-control" placeholder="New Password" required>
        </div>
        <button type="submit" class="btn btn-success">Update Password</button>
    </form>
</div>
</div>
<script>
$(document).ready(function () {
    // Fade out success alert after 3 seconds
    $("#successMessage").delay(3000).fadeOut(500);
    $("#dangerMessage").delay(3000).fadeOut(500);

      let countdown = 300; // 5 minutes in seconds
      const countdownEl = document.getElementById("countdown");
      const timer = setInterval(() => {
      const minutes = Math.floor(countdown / 60);
      const seconds = countdown % 60;
        countdownEl.textContent = `OTP will expire in ${minutes}:${seconds.toString().padStart(2, '0')} minutes`;

        if (countdown <= 0) {
            clearInterval(timer);
            countdownEl.textContent = "⛔ OTP has expired. Please request a new one.";
        }

        countdown--;
    }, 1000);

});
</script>
<?= $this->endSection() ?>
