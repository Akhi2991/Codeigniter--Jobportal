<?= $this->extend('layouts/base') ?>
<?= $this->section('content') ?>
<style>
.text-center{
        color:white!important;
        font-weight:Bold;
      }
    .highlight-box {
      font-size: 1.2rem;
      color: #ffffff;
      position: relative;
      background-color: #0d6efd;
  }

  .highlight-box::after,
  .highlight-box::before {
    content: '';
    position: absolute;
    width: 100%;
    height: 2px;
    background: linear-gradient(to right, #ff0000, #00ffff);
    bottom: -5px;
    left: 0;
    transform: scaleX(0);
    transform-origin: right;
    transition: transform 0.4s ease-out;
  }

  .highlight-box::before {
    top: -5px;
    transform-origin: left;
  }

  .highlight-box:hover::after,
  .highlight-box:hover::before {
    transform: scaleX(1);
  }
  .nav-link.nav-animate {
    position: relative;
    display: inline-block;
    color: #fff;
    font-weight: 500;
    padding: 8px 12px;
    text-decoration: none;
  }

  .nav-link.nav-animate::after,
  .nav-link.nav-animate::before {
    content: '';
    position: absolute;
    height: 2px;
    width: 100%;
    background: linear-gradient(to right, #00ffff, #ff0000);
    transform: scaleX(0);
    transition: transform 0.4s ease;
  }

  .nav-link.nav-animate::before {
    top: 0;
    left: 0;
    transform-origin: left;
  }

  .nav-link.nav-animate::after {
    bottom: 0;
    left: 0;
    transform-origin: right;
  }

  .nav-link.nav-animate:hover::before,
  .nav-link.nav-animate:hover::after {
    transform: scaleX(1);
  }
  /* Loader style */
      #loader {
          position: fixed;
          top: 0; left: 0;
          width: 100%; height: 100%;
          background: white;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          transition: opacity 0.5s ease;
      }
      #loader.hidden {
          opacity: 0;
          pointer-events: none;
      }
     #arrow-icon {
      animation: bounce-right 1.2s infinite;
      transition: transform 0.3s ease-in-out;
  }

  @keyframes bounce-right {
      0%, 100% { transform: translateX(0); }
      50% { transform: translateX(5px); }
  }
  .btn:hover #arrow-icon {
      animation: bounce-right 1.2s infinite;
  }
  [data-aos^="fade"][data-aos^="fade"] {
    opacity: 2.4!important;
    transition-property: opacity,transform;
  }
  .text-dark {
    color: #000 !important;
  }
  nav.navbar {
      transition: top 0.3s;
      position: sticky;
      top: 0;
      z-index: 1030;
  }
  nav.navbar.scrolled {
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
      background-color: #0d6efd !important;
  }
  .owl-carousel .item {
    padding: 15px;
  }
  .card-title{
    color:var(--bs-secondary-color);
  }
  .owl-nav button.owl-prev,
  .owl-nav button.owl-next {
    background: #0d6efd;
    color: white;
    padding: 6px 12px;
    border-radius: 4px;
    margin: 5px;
  }

  .owl-dots .owl-dot.active span {
    background: #0d6efd;
  }


  /* Background for slider section */
  .trending-section {
    background: linear-gradient(135deg, #0d6efd, #6610f2);
    color: white;
    position: relative;
    overflow: hidden;
  }

  /* Optional decoration */
  .trending-section::before {
    content: '';
    position: absolute;
    top: -60px;
    left: -60px;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.05) 20%, transparent 20%);
    background-size: 50px 50px;
    z-index: 0;
  }

  /* Card styling inside slider */
  .job-card {
    border-radius: 12px;
    transition: transform 0.3s ease-in-out;
  }
  .job-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
  }
  .job-card {
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(8px);
  }
  .company-logo {
    height: 80px;
    object-fit: contain;
    filter: grayscale(20%);
    transition: transform 0.3s ease, filter 0.3s;
  }
  .company-logo:hover {
    transform: scale(1.1);
    filter: grayscale(0%);
  }
  .company-card {
    background: #fff;
    border: 1px solid #eee;
    transition: box-shadow 0.3s ease;
    transform: translateY(-5px);
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
  }
  .company-card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    transform: translateY(-5px);
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
  }

  @media (min-width: 992px) {
    .navbar-nav .nav-link {
      padding: 0.5rem 1rem;
      font-size: 1rem;
    }
  }
  @media (max-width: 991px) {
    .navbar-nav {
      background-color: #0d6efd;
      padding: 1rem;
      border-radius: 10px;
    }

</style>

<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="card shadow p-4" style="width: 100%; max-width: 450px;">
            <h3 class="text-center mb-4 text-primary" style="color:black!important;">Create Your Account</h3>

            <?php if (isset($validation)): ?>
                <div class="alert alert-danger" id="dangerMessage1"><?= $validation->listErrors() ?></div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger" id="dangerMessage2"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <form method="post" action="<?= site_url('auth/postregister') ?>">
                    <?= csrf_field() ?>
                <div class="mb-3">
                    <label for="name" class="form-label">Full Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Enter your full name" value="<?= set_value('name') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email address</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="you@example.com" value="<?= set_value('email') ?>" required>
                </div>

                 <div class="mb-3">
                    <label for="phone" class="form-label">Phone</label>
                    <input type="text" name="phone" id="phone" class="form-control" placeholder="you@example.com" value="<?= set_value('phone') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Choose a secure password" value="<?= set_value('password') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="role" class="form-label">I am a</label>
                    <select name="role" class="form-control" required>
                         <option value="">-- Select Role --</option>
                         <option value="user" <?= set_value('role') == 'user' ? 'selected' : '' ?>>Job Seeker</option>
                        <option value="employer" <?= set_value('role') == 'employer' ? 'selected' : '' ?>>Employer</option>
                    </select>
                </div>

                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary" name="register">Register</button>
                </div>

                <div class="text-center">
                    <a href="<?= site_url('auth/login') ?>" class="text-decoration-none">Already have an account? Login</a>
                </div>
            </form>
        </div>
    </div>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <!-- OwlCarousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <!-- OwlCarousel JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
$(document).ready(function () {
    // Fade out success alert after 3 seconds
    $("#dangerMessage1").delay(3000).fadeOut(500);
    $("#dangerMessage2").delay(3000).fadeOut(500);

});
</script>

<?= $this->endSection() ?>
