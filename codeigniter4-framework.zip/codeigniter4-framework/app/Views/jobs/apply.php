<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5" style="max-width: 800px;">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id'))) ?>">⬅ Back to Dashboard</a>
    </div>
    <div class="card shadow-sm border-0">
        <div class="card-body">
            <h4 class="mb-4 text-primary">📄 Apply for: <?= esc($job['title']) ?></h4>

            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>
            <?php if(session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <form method="post" action="<?= site_url('jobs/apply/' . $job['id']) ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>
                
                <div class="mb-3">
                    <label for="cover_letter" class="form-label">✉️ Cover Letter</label>
                    <textarea name="cover_letter" id="cover_letter" rows="5" class="form-control" placeholder="Write a brief cover letter..." required></textarea>
                </div>

                <div class="mb-3">
                    <label for="resume" class="form-label">📎 Upload Resume (PDF, DOC, DOCX)</label>
                    <input type="file" name="resume" id="resume" class="form-control" accept=".pdf,.doc,.docx" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">🚀 Submit Application</button>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
