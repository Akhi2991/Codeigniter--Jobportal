<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="max-w-7xl mx-auto mt-10 px-4 sm:px-6 lg:px-8">
    <h2 class="text-3xl font-extrabold text-green-700 mb-6 flex items-center gap-2">
        📦 <span>Archived Jobs</span>
    </h2>
     <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success" id="SuccessMessage"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>

    <?php if (!empty($jobs)): ?>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <?php foreach ($jobs as $job): ?>
                <div class="bg-white border border-gray-200 rounded-2xl shadow hover:shadow-lg transition-all duration-300 p-5 flex flex-col justify-between h-full">
                    
                    <!-- Job Title -->
                    <h3 class="text-lg font-semibold text-gray-800 mb-2 leading-snug line-clamp-2">
                        <?= esc($job['title']) ?>
                    </h3>

                    <!-- Job Description -->
                    <p class="text-sm text-gray-600 line-clamp-3 flex-grow">
                        <?= esc(word_limiter($job['description'], 20)) ?>
                    </p>

                    <!-- Job Footer -->
                    <div class="mt-4 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2 text-xs">
                        <div class="text-gray-500 flex items-center gap-1">
                            🕒 <?= date('d M Y', strtotime($job['updated_at'])) ?>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-medium">
                                Archived
                            </span>
                            <a href="<?= site_url('jobs/restore/' . $job['id']) ?>"
                               class="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-blue-100 text-blue-700 hover:bg-blue-200 text-xs font-medium transition">
                                🔄 Restore
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-lg text-center">
            No archived jobs found.
        </div>
    <?php endif; ?>
</div>
<script type="text/javascript">
 $(document).ready(function () {
    // Fade out success alert after 3 seconds
    $("#SuccessMessage").delay(3000).fadeOut(500);
    location.reload();
});
</script>   
<?= $this->endSection() ?>
