<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
  <div class="card shadow-sm border-0">
    <div class="card-body">
      <h3 class="text-primary text-center mb-4">💾 Saved Jobs</h3>

      <?php if ($jobs): ?>
        <ul class="list-group list-group-flush" style="max-height: 500px; overflow-y: auto;">
          <?php foreach ($jobs as $job): ?>
            <li class="list-group-item py-3">
              <div class="d-flex justify-content-between align-items-start flex-wrap">
                <div class="me-3">
                  <h5 class="mb-1"><?= esc($job['title']) ?></h5>
                  <p class="mb-1 text-muted">
                    📍 <?= esc($job['location']) ?> &nbsp;|&nbsp; 💰 <?= esc($job['salary']) ?>
                  </p>
                  <p class="mb-1 text-muted">Saved On: 
                    <?= date('d/m/y h:i A', strtotime($job['created_at'])) ?>
                  </p>

                  <?php if (strtotime($job['expires_at']) < time()): ?>
                    <span class="badge bg-danger">Job Expired</span>
                  <?php else: ?>
                    <span class="badge bg-success">Active</span>
                  <?php endif; ?>
                </div>

                <?php if (strtotime($job['expires_at']) >= time()): ?>
                  <div class="mt-2 mt-md-0">
                    <a href="<?= site_url('jobs/view/' . $job['id']) ?>" class="btn btn-outline-primary btn-sm">
                      View Job
                    </a>
                  </div>
                <?php endif; ?>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <div class="alert alert-info text-center mb-0">
          No saved jobs or all saved jobs have already been applied to.
        </div>
      <?php endif; ?>
    </div>
  </div>
</div><br/><br/>

<?= $this->endSection() ?>
