<?php if (session()->get('isLoggedIn')): ?>

<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>
<style>
    .card-title {
    font-weight: bold;
}
.card-text {
    font-size: 14px;
}
/*.job-skeleton {
    background-color: #f0f0f0;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    height: 160px;
    margin-bottom: 1rem;
}
.job-skeleton::before {
    content: "";
    display: block;
    position: absolute;
    height: 100%;
    width: 40%;
    background: linear-gradient(to right, #f0f0f0 0%, #e0e0e0 50%, #f0f0f0 100%);
    animation: shimmer 1.5s infinite;
}*/
@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}
.card.job-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.card.job-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
}

.outer-div {
  position: relative;
  background: rgba(11, 159, 232, 0.48)!important; /* transparent effect */
  width: 100%;
  min-height: 100vh;
  padding: 40px 0;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.15);
  z-index: 1;
}

/* Diamond background shape (optional) */
.outer-div::before {
  content: "";
  position: absolute;
  width: 300px;
  height: 300px;
  background:rgba(11, 159, 232, 0.48)!important;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(45deg);
  box-shadow: 0 0 40px rgba(13, 110, 253, 0.4);
  z-index: 0;
  opacity: 0.2;
  border-radius: 12px;
}

.outer-div .container {
  position: relative;
  z-index: 2;
}
.mb-4{
    color:white!important;
}
</style>
<script>
/*AOS.init({ once: true, duration: 800 });
window.addEventListener('load', () => {
    const loader = document.getElementById('job-loader');
    if (loader) loader.remove();
});*/

document.addEventListener("DOMContentLoaded", function () {
    const csrfTokenName = "<?= csrf_token() ?>";
    const csrfHash = "<?= csrf_hash() ?>";

    document.querySelectorAll('.toggle-save-btn').forEach(button => {
        button.addEventListener('click', function () {
            const jobId = this.getAttribute('data-job-id');
            const btn = this;

            fetch("<?= site_url('jobs/toggle-save') ?>", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: `job_id=${jobId}&${csrfTokenName}=${csrfHash}`
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (data.saved) {
                        btn.textContent = '✔ Saved';
                        btn.classList.remove('btn-outline-primary');
                        btn.classList.add('btn-outline-success');
                    } else {
                        btn.textContent = '💾 Save Job';
                        btn.classList.remove('btn-outline-success');
                        btn.classList.add('btn-outline-primary');
                    }
                } else {
                    alert(data.message || 'Action failed');
                }
            })
            .catch(err => {
                console.error('Fetch error:', err);
                alert('Error sending request.');
            });
        });
    });
});
</script>
<div class="outer-div">
<div class="container mt-4">
    <h3 class="mb-4">Browse Jobs</h3>

    <form method="get" action="<?= site_url('jobs') ?>" class="row g-2 mb-4">
         <div class="col-md-3">
            <input type="text" name="keyword" class="form-control" placeholder="Job title or description" value="<?= esc(request()->getGet('keyword')) ?>">
         </div>
         <div class="col-md-3">
            <input type="text" name="location" class="form-control" placeholder="Location" value="<?= esc(request()->getGet('location')) ?>">
        </div>
        <!--<div class="col-12 col-md-2">
            <input type="text" name="salary" class="form-control" placeholder="Salary" value="<?= esc(request()->getGet('salary')) ?>">
        </div>-->
        <div class="col-md-2">
            <select name="type" class="form-select">
                <option value="">All Types</option>
                <option value="Full Time" <?= request()->getGet('type') === 'Full Time' ? 'selected' : '' ?>>Full Time</option>
                <option value="Part Time" <?= request()->getGet('type') === 'Part Time' ? 'selected' : '' ?>>Part Time</option>
                <option value="Internship" <?= request()->getGet('type') === 'Internship' ? 'selected' : '' ?>>Internship</option>
            </select>
        </div>
        
        <div class="col-12 col-md-2 d-grid">
           <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>
    

    <div class="row" style="max-height: 500px; overflow-y: auto;">
        <?php if ($jobs): ?>
            <?php foreach ($jobs as $job): ?>
                <div class="col-md-6 mb-4"  data-aos="fade-up">
                    <div class="card shadow-sm h-100 job-card border-0">
                        <div class="card-body">
                            <h5 class="card-title"><?= esc($job['title']) ?></h5>
                            <p class="card-text text-muted mb-1">📍<strong>Location:</strong> <?= esc($job['location']) ?></p>
                             <p class="card-text text-muted mb-1">💼<strong>Type:</strong> <?= esc($job['type']) ?></p>
                            <p class="card-text text-muted mb-1">💰<strong>Salary:</strong> <?= esc($job['salary']) ?></p>
                            <p class="card-text"><?= word_limiter(strip_tags($job['description']), 25) ?></p>
                            <p><strong>Expires On:</strong> <?= date('d M Y', strtotime($job['expires_at'])) ?></p>

                            <?php if (strtotime($job['expires_at']) < strtotime(date('Y-m-d'))): ?>
                                <span class="badge bg-danger">Expired</span>

                            <?php endif; ?>


                               <div class="d-flex justify-content-between align-items-center mt-3">
                                

                                <?php if (strtotime($job['expires_at']) < time()): ?>
                                    <button class="btn btn-primary" disabled>Job Expired</button>
                                 <?php else: ?>

                                 <a href="<?= site_url('jobs/view/' . $job['id']) ?>" class="btn btn-sm btn-outline-primary">View</a>

                                <?php if (isset($appliedJobs) && in_array($job['id'], $appliedJobs)): ?>
                                    <button class="btn btn-sm btn-primary" disabled>Applied</button>
                                <?php else: ?>
                                    <a href="<?= site_url('jobs/apply/' . $job['id']) ?>" class="btn btn-sm btn-primary">Apply Now</a>
                                <?php endif; ?>
                               

                                <?php if (session()->get('isLoggedIn') && session()->get('user_role') === 'user'): ?>
                                <?php
                                    $savedModel = new \App\Models\SavedJobModel();
                                    $isSaved = false;
                                    if (session()->get('isLoggedIn')) {
                                    $isSaved = $savedModel->where([
                                        'user_id' => session()->get('user_id'),
                                        'job_id'  => $job['id']
                                    ])->first();
                                }
                                ?>
                                <?php if (isset($appliedJobs) && in_array($job['id'], $appliedJobs)): ?>
                                 <button class="btn btn-sm toggle-save-btn btn-outline-<?= $isSaved ? 'success' : 'secondary' ?>" data-job-id="<?= $job['id'] ?>" disabled>
                                    <?= $isSaved ? '✔ Saved' : '💾 Save Job' ?>
                                 </button>
                                 <?php else: ?>
                                 <button class="btn btn-sm toggle-save-btn btn-outline-<?= $isSaved ? 'success' : 'secondary' ?>" data-job-id="<?= $job['id'] ?>">
                                    <?= $isSaved ? '✔ Saved' : '💾 Save Job' ?>
                             <?php endif; ?>
                             <?php endif; ?> 
                             <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <!-- ✅ Skeleton Loader -->
            <!--<div id="job-loader">
                <div class="job-skeleton"></div>
                <div class="job-skeleton"></div>
            </div>-->
        <?php else: ?>
            <div class="alert alert-warning" style="max-width:83%!important"><p class="text-center"><b><strong>No jobs found matching your criteria</b></strong></p></div>
        <?php endif; ?>
    </div>

    <div class="mt-3">
        <?= $pager->links() ?>
    </div>
</div>
</div>
<?= $this->endSection() ?>

<?php else: ?>
<?= $this->extend('layouts/base') ?>
<?= $this->section('content') ?>
<style>
    .card-title {
    font-weight: bold;
}
.card-text {
    font-size: 14px;
}
 .card-title {
    font-weight: bold;
}
.card-text {
    font-size: 14px;
}
/*.job-skeleton {
    background-color: #f0f0f0;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    height: 160px;
    margin-bottom: 1rem;
}
.job-skeleton::before {
    content: "";
    display: block;
    position: absolute;
    height: 100%;
    width: 40%;
    background: linear-gradient(to right, #f0f0f0 0%, #e0e0e0 50%, #f0f0f0 100%);
    animation: shimmer 1.5s infinite;
}*/
@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}
.card.job-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.card.job-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
}
.mb-4{
    color:white!important;
}
.outer-div {
  position: relative;
  background: rgba(11, 159, 232, 0.48)!important; /* transparent effect */
  width: 100%;
  min-height: 100vh;
  padding: 40px 0;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.15);
  z-index: 1;
}

/* Diamond background shape (optional) */
.outer-div::before {
  content: "";
  position: absolute;
  width: 300px;
  height: 300px;
  background:rgba(11, 159, 232, 0.48)!important;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(45deg);
  box-shadow: 0 0 40px rgba(13, 110, 253, 0.4);
  z-index: 0;
  opacity: 0.2;
  border-radius: 12px;
}

.outer-div .container {
  position: relative;
  z-index: 2;
}

</style>
<div class="outer-div">
 <div class="container mt-4">
    <h3 class="mb-4">Browse Jobs</h3>

    <form method="get" action="<?= site_url('jobs') ?>" class="row g-2 mb-4">
         <div class="col-12 col-md-3">
            <input type="text" name="keyword" class="form-control" placeholder="Job title or description" value="<?= esc(request()->getGet('keyword')) ?>">
         </div>
         <div class="col-12 col-md-3">
            <input type="text" name="location" class="form-control" placeholder="Location" value="<?= esc(request()->getGet('location')) ?>">
        </div>
        <!--<div class="col-12 col-md-2">
            <input type="text" name="salary" class="form-control" placeholder="Salary" value="<?= esc(request()->getGet('salary')) ?>">
        </div>-->
        <div class="col-md-2">
            <select name="type" class="form-select">
                <option value="">All Types</option>
                <option value="Full Time" <?= request()->getGet('type') === 'Full Time' ? 'selected' : '' ?>>Full Time</option>
                <option value="Part Time" <?= request()->getGet('type') === 'Part Time' ? 'selected' : '' ?>>Part Time</option>
                <option value="Internship" <?= request()->getGet('type') === 'Internship' ? 'selected' : '' ?>>Internship</option>
            </select>
        </div>
        <div class="col-md-2 d-grid">
           <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>
    

    <div class="row" style="max-height: 500px; overflow-y: auto;">
        <?php if ($jobs): ?>
            <?php foreach ($jobs as $job): ?>
                <div class="col-md-6 mb-4" data-aos="fade-up">
                    <div class="card shadow-sm h-100 job-card border-0">
                        <div class="card-body">
                            <h5 class="card-title"><?= esc($job['title']) ?></h5>
                            <p class="card-text text-muted mb-1">📍<strong>Location:</strong> <?= esc($job['location']) ?></p>
                             <p class="card-text text-muted mb-1">💼<strong>Type:</strong> <?= esc($job['type']) ?></p>
                            <p class="card-text text-muted mb-1">💰<strong>Salary:</strong> <?= esc($job['salary']) ?></p>
                            <p class="card-text"><?= word_limiter(strip_tags($job['description']), 25) ?></p>
                            <p><strong>Expires On:</strong> <?= date('d M Y', strtotime($job['expires_at'])) ?></p>

                            <?php if (strtotime($job['expires_at']) < strtotime(date('Y-m-d'))): ?>
                                <span class="badge bg-danger">Expired</span>
                            <?php endif; ?>

                                <a href="<?= site_url('auth/login') ?>" class="btn btn-primary">Login to Apply</a>
                                <p class="text-muted mt-2">Don't have an account? <a href="<?= site_url('auth/register') ?>" class="btn btn-primary">Register now</a></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
             <!-- ✅ Skeleton Loader -->
            <!--<div id="job-loader">
                <div class="job-skeleton"></div>
                <div class="job-skeleton"></div>
            </div>-->
        <?php else: ?>
            <div class="alert alert-warning" style="max-width:83%!important"><p class="text-center" style="color:black!important;"><b><strong>No jobs found matching your criteria</b></strong></p></div>
        <?php endif; ?>
    </div>

    <div class="mt-3">
        <?= $pager->links() ?>
    </div>
</div>
</div>
<!-- ✅ JS -->
<script>
/*AOS.init({ once: true, duration: 800 });
window.addEventListener('load', () => {
    const loader = document.getElementById('job-loader');
    if (loader) loader.remove();
});*/
</script>

<?= $this->endSection() ?>

<?php endif; ?>

