<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5" style="max-width: 700px;">
    <?php if (isset($validation)): ?>
        <div class="alert alert-danger"><?= $validation->listErrors() ?></div>
    <?php endif; ?>

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
         <h4 class="mb-0"> 📋  Post Jobs</h4>
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id'))) ?>">⬅ Back to Dashboard</a>
    </div>
   <div class="row row-cols-1 g-3" >
    <div class="col">
    <div class="card shadow-sm border-0">
        <div class="card-body" style="max-height: 500px; overflow-y: auto;">
            <form method="post" action="<?= site_url('jobs/post') ?>">
                    <?= csrf_field() ?>
                 <div class="mb-3">
                     <label class="form-label">Job Categories</label>
                     <select name="category_id" class="form-control" required>
                        <option value="">-- Select Category --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= esc($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label class="form-label">Job Tags</label>
                    <select name="tags[]" class="form-control" multiple>
                        <?php foreach ($tags as $tag): ?>
                            <option value="<?= $tag['id'] ?>"><?= esc($tag['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Job Title</label>
                    <input type="text" name="title" class="form-control" placeholder="e.g. Frontend Developer" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4" placeholder="Describe the role..." required></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Location</label>
                    <input type="text" name="location" class="form-control" placeholder="e.g. Remote, Mumbai">
                </div>
                <div class="mb-3">
                    <label class="form-label">Salary</label>
                    <input type="text" name="salary" class="form-control" placeholder="e.g. ₹40,000/month">
                </div>
                  <div class="mb-3">
                    <label class="form-label">Experience Level</label>
                    <select name="experience_level" class="form-control" required>
                        <option value="">-- Select Level --</option>
                        <option value="Entry">Entry</option>
                        <option value="Mid">Mid</option>
                        <option value="Senior">Senior</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Job Type</label>
                    <select name="job_type" class="form-control" required>
                        <option value="Full-time">Full-time</option>
                        <option value="Freelance">Freelance</option>
                        <option value="Internship">Internship</option>
                        <option value="Part-time">Part-time</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Work Mode</label>
                    <select name="is_remote" class="form-control" required>
                        <option value="Remote">Remote</option>
                        <option value="Onsite">Onsite</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Job Expiry Date</label>
                    <input type="date" name="expires_at" class="form-control" required>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">🚀 Post Job</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
<br/><br/>

<?= $this->endSection() ?>
