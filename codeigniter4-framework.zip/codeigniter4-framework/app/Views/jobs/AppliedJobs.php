<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>


<div class="container mt-5">
    <div class="card shadow">
        <div class="card-body">
            <h3 class="text-primary text-center mb-4">📄 Applied Jobs</h3>
             <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success" id="SuccessMessage"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger" id="ErrorMessage"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <?php if ($jobs): ?>
                <ul class="list-group" style="max-height: 500px; overflow-y: auto;">
                    <?php foreach ($jobs as $job): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <strong><?= esc($job['title']) ?></strong><br>
                                <?= esc($job['location']) ?> - <?= esc($job['salary']) ?><br>
                                <small>Applied On: <?= date('d/m/y h:i A', strtotime($job['created_at'])) ?></small><br>
                                <?php if (strtotime($job['expires_at']) < time()): ?>
                                    <span class="badge bg-danger">Expired</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Active</span>
                                <?php endif; ?>
                            </div>

                            <!-- 3-dot dropdown menu -->
                            <div class="dropdown">
                                <button class="btn btn-light btn-sm" type="button" id="dropdownMenuButton<?= $job['id'] ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton<?= $job['id'] ?>">
                                    <?php if (strtotime($job['expires_at']) < time()): ?>
                                   
                                       <a class="dropdown-item text-danger report-job-btn" href="#" 
                                           data-job-id="<?= $job['id'] ?>" 
                                           data-bs-toggle="modal" 
                                           data-bs-target="#reportModal">
                                           🛑 Report Job
                                      </a>
                                   

                                <?php else: ?>
                                     <li>
                                        <a class="dropdown-item" href="<?= site_url('jobs/view/' . $job['id']) ?>">👁️ View Job</a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item text-danger" href="<?= site_url('jobs/withdraw/' . $job['id']) ?>" onclick="return confirm('Withdraw your application?')">❌ Withdraw</a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('jobs/archive/' . $job['id']) ?>">📧 Archive</a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('chat/employer/' . $job['id']) ?>">📧 Contact Employer</a>
                                    </li>

                                     <a class="dropdown-item text-danger report-job-btn" href="#" 
                                           data-job-id="<?= $job['id'] ?>" 
                                           data-bs-toggle="modal" 
                                           data-bs-target="#reportModal">
                                           🛑 Report Job
                                      </a>
                                <?php endif; ?>
                                </ul>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="alert alert-warning text-center">
                    <strong>No applied jobs found.</strong>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
                                       <!-- Report Modal -->
                                    <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <form method="post" action="<?= site_url('jobs/report') ?>">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="job_id" id="reportJobId">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title text-danger" id="reportModalLabel">Report Job</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <label>Reason for reporting:</label>
                                                    <textarea name="reason" class="form-control" required placeholder="Describe the issue..."></textarea>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-danger">Submit Report</button>
                                                </div>
                                            </div>
                                        </form>
                                      </div>
                                    </div>
<br/><br/>
<script type="text/javascript">
 document.querySelectorAll('.dropdown-menu a').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelector('.dropdown-menu.show')?.classList.remove('show');
  });
});

 document.querySelectorAll('.report-job-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        const jobId = this.getAttribute('data-job-id');
        document.getElementById('reportJobId').value = jobId;
    });
});
 $(document).ready(function () {
    // Fade out success alert after 3 seconds
    $("#SuccessMessage").delay(3000).fadeOut(500);
    $("#ErrorMessage").delay(3000).fadeOut(500);
    location.reload();
});
</script>

<?= $this->endSection() ?>
