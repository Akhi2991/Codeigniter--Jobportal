<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <div class="card shadow-lg border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="bi bi-pencil-square"></i> Edit Job</h4>
            <a href="<?= site_url('jobs/manage') ?>" class="btn btn-light btn-sm">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>
        <div class="card-body" style="max-height: 500px; overflow-y: auto;">
            <form method="post" action="<?= site_url('jobs/update/' . $job['id']) ?>">
                    <?= csrf_field() ?>
                <div class="mb-3">
                    <label>Category</label>
                    <select name="category_id" class="form-control" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $job['category_id'] ? 'selected' : '' ?>>
                                <?= esc($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Tags</label>
                    <select name="tags[]" class="form-control" multiple>
                        <?php foreach ($tags as $tag): ?>
                            <option value="<?= $tag['id'] ?>" <?= in_array($tag['id'], $selectedTags) ? 'selected' : '' ?>>
                                <?= esc($tag['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Job Title</label>
                    <input type="text" name="title" class="form-control" value="<?= esc($job['title']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Description</label>
                    <textarea name="description" class="form-control" rows="5" required><?= esc($job['description']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Location</label>
                    <input type="text" name="location" class="form-control" value="<?= esc($job['location']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Salary</label>
                    <input type="text" name="salary" class="form-control" value="<?= esc($job['salary']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Job Expiry Date</label>
                    <input type="date" name="expires_at" class="form-control" 
                           value="<?= esc(date('Y-m-d', strtotime($job['expires_at']))) ?>" required>
                </div>

              <div class="mb-3">
                    <label class="form-label">Experience Level</label>
                    <select name="experience_level" class="form-control">
                        <?php foreach (['Entry', 'Mid', 'Senior'] as $level): ?>
                            <option value="<?= $level ?>" <?= $job['experience_level'] === $level ? 'selected' : '' ?>><?= $level ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Job Type</label>
                    <select name="job_type" class="form-control">
                        <?php foreach (['Full-time', 'Part-time', 'Freelance', 'Internship'] as $type): ?>
                            <option value="<?= $type ?>" <?= $job['job_type'] === $type ? 'selected' : '' ?>><?= $type ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Work Mode</label>
                    <select name="is_remote" class="form-control">
                        <option value="Remote" <?= $job['is_remote'] ? 'selected' : '' ?>>Remote</option>
                        <option value="Onsite" <?= !$job['is_remote'] ? 'selected' : '' ?>>Onsite</option>
                    </select>
                </div>


                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> Update Job
                    </button>

                    <a href="<?= site_url('jobs/manage') ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-x-circle"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div><br/>

<?= $this->endSection() ?>
