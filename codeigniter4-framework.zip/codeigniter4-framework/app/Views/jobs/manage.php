<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
        <h4 class="mb-0"><i class="bi bi-pencil-square"></i> 📋 Manage Your Posted Jobs</h4>
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id')))  ?>"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
    </div>

    <?php if ($jobs): ?>
       <!-- ✅ Scroll container -->
    <div style="max-height: 500px; overflow-y: auto; padding-right:5px;">
        <div class="row row-cols-1 g-3">
            <?php foreach ($jobs as $job): ?>
                <div class="col">
                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-body">
                            <h5 class="card-title text-dark"><?= esc($job['title']) ?></h5>
                            <p class="card-text text-muted mb-2"><?= esc($job['description']) ?></p>
                            <p class="card-text">
                                <i class="bi bi-geo-alt-fill text-danger"></i> <?= esc($job['location']) ?>
                                <span class="ms-3"><i class="bi bi-currency-rupee"></i> <?= esc($job['salary']) ?></span>
                            </p>
                             <p><strong>Category:</strong> <?= esc($job['category_name'] ?? 'Uncategorized') ?></p>
                             <p><strong>Experience-level:</strong> <?= esc($job['experience_level']) ?></p>
                             <p>
                             <p><strong>Job Type:</strong> <?= esc($job['job_type']) ?></p>
                             <p>
                             <p><strong>Workmode:</strong> <?= esc($job['is_remote']) ?></p>
                             <p>
                                <strong>Tags:</strong>
                                    <?php if (!empty($job['tags'])): ?>
                                        <?php foreach ($job['tags'] as $tag): ?>
                                            <span class="badge bg-secondary"><?= esc($tag) ?></span>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <span class="text-muted">No tags</span>
                                    <?php endif; ?>
                             </p>
                            <?php
                            $today = strtotime(date('Y-m-d'));
                            $expires = strtotime($job['expires_at']);
                            $daysLeft = round(($expires - $today) / 86400);
                            ?>

                            <?php if ($daysLeft <= 3 && $daysLeft >= 0): ?>
                                <span class="badge bg-warning text-dark">Job Expiring in <?= $daysLeft ?> day<?= $daysLeft == 1 ? '' : 's' ?></span>
                            <?php elseif ($expires < $today): ?>
                                <span class="badge bg-danger">Job Expired</span>
                            <?php endif; ?>
                            <div class="text-end">
                                <a href="<?= site_url('jobs/edit/' . $job['id']) ?>" class="btn btn-outline-warning btn-sm me-2">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </a>
                                <a href="<?= site_url('jobs/delete/' . $job['id']) ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure?')">
                                    <i class="bi bi-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-info">You haven't posted any jobs yet.</div>
    <?php endif ?>
    </div><br/><br/>
    <?= $this->endSection() ?>

