<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<style>
    .job-detail-card {
        background: #ffffff;
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }
    .job-detail-card h3 {
        font-weight: bold;
    }
    .job-meta p {
        margin-bottom: 8px;
        font-size: 16px;
    }
    .job-meta i {
        margin-right: 8px;
        color: #0d6efd;
    }
</style>

<div class="container mt-5" style="max-width: 850px;">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center" style="height:50px!important;">
         <h4 class="mb-0"> 📋  Post Jobs</h4>
        <a class="btn btn-light btn-sm" href="<?= site_url('dashboard/' . safe_base64_encode(session('user_id'))) ?>">⬅ Back to Dashboard</a>
    </div>

    <div class="job-detail-card">
        <h3 class="text-primary"><?= esc($job['title']) ?></h3>
        <hr>

        <div class="job-meta">
            <p><i class="bi bi-geo-alt-fill"></i><strong>Location:</strong> <?= esc($job['location']) ?: 'Not specified' ?></p>
            <p><i class="bi bi-currency-rupee"></i><strong>Salary:</strong> <?= esc($job['salary']) ?: 'Negotiable' ?></p>
            <p><i class="bi bi-eye-fill"></i><strong>Views:</strong> <?= esc($job['views']) ?></p>
            <p><i class="bi bi-calendar-event-fill"></i><strong>Expires On:</strong> <?= date('d M Y', strtotime($job['expires_at'])) ?></p>
        </div>

        <div class="mt-4">
            <h5 class="mb-2"><i class="bi bi-card-text"></i> Job Description:</h5>
            <p class="text-muted" style="line-height: 1.7"><?= nl2br(esc($job['description'])) ?></p>
        </div>

        <?php if (session()->get('isLoggedIn') && session()->get('user_role') === 'user'): ?>
            <div class="mt-4">
                <?php if ($hasApplied): ?>
                    <button class="btn btn-success" disabled>✅ Already Applied</button>
                    <p class="text-success mt-2">You’ve already applied for this position.</p>
                <?php else: ?>
                    <a href="<?= site_url('jobs/apply/' . $job['id']) ?>" class="btn btn-primary">
                        🚀 Apply Now
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div><br/><br/>

<!-- Bootstrap Icons (Optional if not already included) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<?= $this->endSection() ?>
