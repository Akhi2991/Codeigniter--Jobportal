<?= $this->extend('layouts/base') ?>
<?= $this->section('content') ?>

<!-- ✅ Hero Banner -->
<div class="bg-light py-5">
  <div class="container text-center">
    <h1 class="display-5 fw-bold" style="color:black!important;">Find Your Dream Job</h1>
    <p class="lead" style="color:black!important">Browse thousands of job opportunities from top companies.</p>
<a href="<?= site_url('jobs') ?>" class="btn btn-primary px-4 py-2 d-inline-flex align-items-center gap-2"  >
    Browse Jobs
    <svg id="arrow-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-arrow-right" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M10.146 12.354a.5.5 0 0 1-.708-.708L12.293 9H1.5a.5.5 0 0 1 0-1h10.793L9.438 4.354a.5.5 0 1 1 .708-.708l3.5 3.5a.5.5 0 0 1 0 .708l-3.5 3.5z"/>
    </svg>
</a>
</div>
</div>
<!-- ✅ Features or Categories -->
<div class="container my-5">
  <div class="row text-center">
    <div class="col-md-4" >
      <div class="card highlight-box shadow-sm p-4 mb-4">
        <h5 class="mb-3">🔍 Easy Job Search</h5>
        <p>Use keywords, location, and filters to quickly find relevant jobs.</p>
      </div>
    </div>
    <div class="col-md-4"  >
      <div class="card highlight-box shadow-sm p-4 mb-4">
        <h5 class="mb-3">👤 Applicant Profile</h5>
        <p>Create a profile and upload your resume to apply faster.</p>
      </div>
    </div>
    <div class="col-md-4" >
      <div class="card highlight-box shadow-sm p-4 mb-4">
        <h5 class="mb-3">🏢 Employer Dashboard</h5>
        <p>Post jobs and manage applicants with a simple interface.</p>
      </div>
    </div>
  </div>
</div>

<!-- ✅ Call to Action -->
<div class="bg-primary text-white text-center py-5">
  <h2>Ready to Get Started?</h2>
  <p>Join as a job seeker or employer today.</p>
  <a href="<?= site_url('auth/register') ?>" class="btn btn-light btn-lg mt-2">Create an Account</a>
</div>

<section class="section bg-light text-dark" id="features">
  <div class="container py-5" data-aos="fade-up">
    <h2 class="text-center mb-4" style="color:black!important;">Platform Features</h2>
    <div class="row text-center">
      <div class="col-md-4">
        <div class="p-4 bg-white shadow rounded text-dark" style="color:black!important;">
          <h5>Easy Job Search</h5>
          <p>Filter jobs by category, location, and salary.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4 bg-white shadow rounded text-dark" style="color:black!important;">
          <h5>Secure Application</h5>
          <p>Apply securely with your uploaded resume.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4 bg-white shadow rounded text-dark" style="color:black!important;">
          <h5>Employer Dashboard</h5>
          <p>Post jobs, manage applicants, and track applications.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section text-dark" id="about" style="background-color:#f7f7f7;" data-aos="fade-left">
  <div class="container py-5" >
    <h2 class="text-center" style="color:black!important;">Why Choose Us</h2>
    <p class="text-center w-75 mx-auto" style="color:black!important;">Our platform connects job seekers with top companies. We ensure a seamless experience with built-in resume upload, application tracking, and employer communication tools.</p>
  </div>
</section>

<section class="trending-section text-white py-5">
  <div class="container" data-aos="fade-up">
    <h2 class="text-center mb-4">🔥 Trending Jobs</h2>

    <?php if (!empty($jobs)): ?>
      <div class="owl-carousel owl-theme">
        <?php foreach ($jobs as $job): ?>
          <div class="item">
            <div class="job-card bg-primary text-white rounded shadow p-4 text-center" style="">
              <h5 class="fw-bold"><?= esc($job['title']) ?></h5>
              <p class="mb-1"><i class="bi bi-geo-alt"></i> <?= esc($job['location']) ?></p>
              <p class="mb-1"><i class="bi bi-cash"></i> <?= esc($job['salary']) ?></p>
              <p><i class="bi bi-eye"></i> <?= esc($job['views'] + 1) ?> views</p>
              <a href="<?= site_url('jobs') ?>" class="btn btn-primary px-4 py-2 d-inline-flex align-items-center gap-2"  >View Jobs</a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-center">No trending jobs available.</p>
    <?php endif; ?>
  </div>
</section>

<section class="py-5 bg-white text-dark" id="top-companies">
  <div class="container">
    <h2 class="text-center mb-4 fw-bold text-dark" data-aos="fade-up">🌟 Top Hiring Companies</h2>

    <div class="top-companies-slider owl-carousel owl-theme" data-aos="fade-up">
      <?php foreach ($topCompanies as $company): ?>
        <div class="item text-center">
          <div class="company-card shadow-sm p-4 bg-light rounded border border-1 border-primary h-100">
            <img src="<?= base_url('uploads/companies/' . $company['logo']) ?>" 
                 class="img-fluid mb-3 company-logo" 
                 alt="<?= esc($company['name']) ?>" 
                 style="max-height: 60px; object-fit: contain;">
            <h6 class="fw-semibold text-dark mb-0"><?= esc($company['name']) ?></h6>
            <p class="mb-0 text-muted small"><?= esc($company['industry']) ?> | <?= esc($company['location']) ?></p>
            <p class="text-primary small">Open Jobs: <?= esc($company['job_count']) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?= $this->endSection() ?>
