<?= $this->extend('layouts/dashboardbase') ?>
<?= $this->section('content') ?>

<div class="container mt-5" style="max-width: 600px;">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">🔔 Subscribe for Job Alerts</h5>
        </div>
        <div class="card-body">
            <form method="post" action="<?= site_url('jobalert/postsubscribe') ?>">
                <?= csrf_field() ?>
                <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
                <?php endif; ?>

        <div class="mb-3">
            <label for="keyword" class="form-label">
                Keyword <small class="text-muted">(optional)</small>
            </label>
            <input type="text" id="keyword" name="keyword" class="form-control"
                   placeholder="e.g. developer, PHP"
                   value="<?= set_value('keyword') ?>" required="">
        </div>

        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            <select id="category" name="category_id" class="form-select">
                <option value="">Any</option>
                <?php foreach ($category as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= set_select('category_id', $cat['id']) ?>>
                        <?= esc($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">📨 Subscribe Now</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
