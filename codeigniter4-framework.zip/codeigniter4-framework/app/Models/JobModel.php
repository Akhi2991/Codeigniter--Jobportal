<?php

namespace App\Models;

use CodeIgniter\Model;

class JobModel extends Model
{
    protected $table      = 'jobs';
    protected $primaryKey = 'id';
    protected $allowedFields = ['employer_id', 'title', 'description', 'location', 'salary', 'expires_at', 'status','category_id','experience_level','job_type','is_remote','views'];
    protected $useTimestamps = true;
    protected $returnType = 'array';
}
