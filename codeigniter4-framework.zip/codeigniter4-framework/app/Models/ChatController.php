<?php

namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use App\Models\MessageModel;

class ChatController extends ResourceController
{
    protected $modelName = MessageModel::class;
    protected $format    = 'json';

    // ✅ Send a message
    public function send()
    {
        $data = $this->request->getJSON(true);

        if (!$this->model->insert($data)) {
            return $this->fail($this->model->errors());
        }

        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Message sent successfully',
            'message_id' => $this->model->getInsertID()
        ]);
    }

    // ✅ Get chat conversation between two users
    public function conversation($userId, $otherId)
    {
        $messages = $this->model
            ->where("(sender_id = $userId AND receiver_id = $otherId) 
                     OR (sender_id = $otherId AND receiver_id = $userId)")
            ->orderBy('created_at', 'ASC')
            ->findAll();

        return $this->respond($messages);
    }

    // ✅ Get unread messages for a user
    public function unread($userId)
    {
        $count = $this->model->where('receiver_id', $userId)->where('is_read', 0)->countAllResults();
        return $this->respond(['unread_count' => $count]);
    }
}
