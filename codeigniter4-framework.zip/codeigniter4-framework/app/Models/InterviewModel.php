<?php

namespace App\Models;

use CodeIgniter\Model;

class InterviewModel  extends Model
{
    protected $table = 'job_interviews';
    protected $primaryKey = 'id';
    protected $allowedFields = ['job_id', 'applicant_id', 'interview_datetime', 'location', 'mode', 'notes'];
}
