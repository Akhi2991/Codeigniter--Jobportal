<?php

namespace App\Models;

use CodeIgniter\Model;

class ApplicationModel extends Model
{
    protected $table = 'applications';
    protected $primaryKey = 'id';
    protected $allowedFields = ['job_id', 'user_id', 'coverletter', 'resume', 'status', 'is_archived'];
    protected $useTimestamps = true;
    protected $deletedField   = 'deleted_at';
    protected $returnType = 'array';
}
