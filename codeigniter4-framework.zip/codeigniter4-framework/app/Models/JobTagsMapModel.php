<?php

namespace App\Models;

use CodeIgniter\Model;

class JobTagsMapModel extends Model
{
    protected $table = 'job_tag_map';
    protected $allowedFields = ['job_id', 'tag_id'];
    protected $useTimestamps = false;
    protected $returnType = 'array';
}
