<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';         // your table name
    protected $primaryKey = 'id';       // primary key

    protected $allowedFields = [
        'name',
        'email',
        'password',
        'role',
        'created_at',
        'updated_at',
        'resume',
        'phone',
        'bio',
        'profile_pic',
        'otp',
        'otp_created_at'
    ];

    protected $useTimestamps = true;    // auto-manage created_at/updated_at
    protected $returnType = 'array';    // return result as associative array

    /**
     * Find user by email
     */
    public function getUserByEmail($email)
    {
        return $this->where('email', $email)
        ->whereIn('role', ['employer', 'user'])->first(); // allow only employer and job seeker   
    }
}
