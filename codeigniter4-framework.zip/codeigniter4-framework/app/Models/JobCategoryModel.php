<?php

namespace App\Models;

use CodeIgniter\Model;

class JobCategoryModel extends Model
{
    protected $table = 'job_categories';
    protected $allowedFields = ['name'];
}
