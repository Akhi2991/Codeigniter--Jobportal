<?php

namespace App\Models;

use CodeIgniter\Model;

class JobTagsModel  extends Model
{
    protected $table = 'job_tags';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name'];
    protected $useTimestamps =  false;
    protected $returnType = 'array';
}
