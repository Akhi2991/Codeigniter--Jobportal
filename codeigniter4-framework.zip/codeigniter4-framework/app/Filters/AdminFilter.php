<?php

namespace App\Filters;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (!session()->get('isAdminLoggedIn')) {
            return redirect()->to('admin/login')->with('error', 'You must be logged in to access that page.');
        }
         // Custom session timeout (15 minutes = 900 seconds)
        $timeout = 900; // seconds
        $lastActivity = session()->get('last_activity');

        if ($lastActivity && (time() - $lastActivity > $timeout)) {
            session()->destroy();
            return redirect()->to('admin/login')->with('error', 'Session timed out due to inactivity.');
        }

        // Update last activity time
        session()->set('last_activity', time());
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No post-response action
    }
}
