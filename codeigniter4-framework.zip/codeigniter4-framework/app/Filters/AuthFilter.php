<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('auth/login')->with('error', 'You must be logged in to access that page.');
             return service('response')
                ->setJSON(['status' => 'error', 'message' => 'Unauthorized'])
                ->setStatusCode(401);
        }
         // Custom session timeout (15 minutes = 900 seconds)
        $timeout = 900; // seconds
        $lastActivity = session()->get('last_activity');

        if ($lastActivity && (time() - $lastActivity > $timeout)) {
            session()->destroy();
            return redirect()->to('auth/login')->with('error', 'Session timed out due to inactivity.');
        }

        // Update last activity time
        session()->set('last_activity', time());
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No post-response action
    }
}
