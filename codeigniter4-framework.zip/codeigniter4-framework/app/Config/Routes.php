<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
///----frontpage----
$routes->get('jobportal', 'Jobportal::index');

//-----register-----
$routes->get('auth/register', 'Auth::register');
$routes->post('auth/postregister', 'Auth::postregister');
//$routes->match(['get', 'post'], 'auth/register', 'Auth::register');

//-------login-----
$routes->get('auth/login', 'Auth::login');
//$routes->match(['get', 'post'], 'auth/login', 'Auth::login');
$routes->post('auth/postlogin', 'Auth::postlogin');
//////--login with otp----
$routes->post('auth/send-otp', 'Auth::sendOtpToPhone');
$routes->post('auth/verify-otp', 'Auth::verifyOtp');

//$routes->get('/dashboard', 'Auth::dashboard');

//---dashboard----
/*$routes->get('/dashboard', function () {
    echo 'Welcome to the Dashboard';
}, ['filter' => 'authGuard']);*/
//$routes->get('/dashboard', 'Dashboard::index', ['filter' => 'authGuard']);
$routes->get('dashboard/(:any)', 'Dashboard::index/$1', ['filter' => 'authGuard']);



//----logout----
$routes->get('auth/logout', 'Auth::logout');

//----postjob----
//$routes->match(['get', 'post'], 'jobs/post', 'Job::post', ['filter' => 'authGuard']);
$routes->get('jobs/postjobs', 'Job::getjobs', ['filter' => 'authGuard']);
$routes->post('jobs/post', 'Job::post', ['filter' => 'authGuard']);
//----managejobs-----
$routes->get('jobs/manage', 'Job::manage', ['filter' => 'authGuard']);
//-----updatejobs-----
$routes->get('jobs/edit/(:num)', 'Job::edit/$1', ['filter' => 'authGuard']);
$routes->post('jobs/update/(:num)', 'Job::update/$1', ['filter' => 'authGuard']);
$routes->get('jobs/delete/(:num)', 'Job::delete/$1', ['filter' => 'authGuard']);

//-----list,apply,submit jobs,status----
$routes->get('jobs', 'Job::list');
$routes->get('jobs/view/(:num)', 'Job::view/$1');
$routes->get('jobs/apply/(:num)', 'Job::apply/$1', ['filter' => 'authGuard']);
$routes->post('jobs/apply/(:num)', 'Job::submitApplication/$1', ['filter' => 'authGuard']);
$routes->get('applications', 'Job::myApplications', ['filter' => 'authGuard']);
$routes->get('jobs/applicants', 'Job::allApplicants', ['filter' => 'authGuard']);
$routes->post('applications/update-status/(:num)', 'Job::updateStatus/$1', ['filter' => 'authGuard']);

////---saved jobs------
//$routes->get('jobs/save/(:num)', 'Job::saveJob/$1', ['filter' => 'authGuard']);
$routes->post('jobs/toggle-save', 'Job::toggleSave', ['filter' => 'authGuard']);
$routes->get('jobs/saved', 'Job::SavedJobs', ['filter' => 'authGuard']);

/////--jobalert-----
$routes->get('jobalert/subscribe', 'Job::subscribe', ['filter' => 'authGuard']);
$routes->post('jobalert/postsubscribe', 'Job::postsubscribe', ['filter' => 'authGuard']);

/////------schedule interview------
$routes->get('job/interview/(:num)/(:num)', 'Job::ScheduleInterview/$1/$2', ['filter' => 'authGuard']);
$routes->post('job/schedule', 'Job::PostScheduleInterview', ['filter' => 'authGuard']);

/////-----applied jobs-------
$routes->get('jobs/AppliedJobs', 'Job::AppliedJobs', ['filter' => 'authGuard']);

//////------report jobs------
$routes->post('jobs/report', 'Job::ReportJobs', ['filter' => 'authGuard']);

/////----withdraw jobs-----
$routes->get('jobs/withdraw/(:num)', 'Job::withdraw/$1', ['filter' => 'authGuard']);

/////-----archieve jobs----
$routes->get('jobs/archive/(:num)', 'Job::archive/$1', ['filter' => 'authGuard']);
$routes->get('jobs/archieved', 'Job::viewarchive', ['filter' => 'authGuard']);

////-----contact employer-----
$routes->get('chat/employer/(:num)', 'Job::ContactEmployer/$1', ['filter' => 'authGuard']);
$routes->get('chat/conversation/(:num)/(:num)', 'Job::conversation/$1/$1', ['filter' => 'authGuard']);
$routes->post('chat/sendMessage', 'Job::sendMessage', ['filter' => 'authGuard']);
$routes->get('chat/fetchMessages/(:num)', 'Job::fetchMessages/$1', ['filter' => 'authGuard']);

/////employer side chat---
$routes->get('chat/inbox/(:num)', 'Job::inbox/$1', ['filter' => 'authGuard']);
$routes->get('chat/view/(:num)', 'Job::viewChat/$1', ['filter' => 'authGuard']);
$routes->post('chat/send', 'Job::SendMessageToEmployee', ['filter' => 'authGuard']);
$routes->get('chat/ajaxMessages/(:num)', 'Job::ajaxMessages/$1', ['filter' => 'authGuard']);

/////restore jobs----
$routes->get('jobs/restore/(:num)', 'Job::RestoreJob/$1', ['filter' => 'authGuard']);


//-----resume---------
$routes->get('profile/resume', 'Profile::resume', ['filter' => 'authGuard']);
$routes->post('profile/replaceresume', 'Profile::ReplaceResume', ['filter' => 'authGuard']);

//---------notification-----------
$routes->get('notification/read/(:num)', 'Job::read/$1');

//-----chats-----
$routes->get('chat', 'Chat::index');
$routes->get('chat/(:num)', 'Chat::index/$1');
$routes->post('chat/send', 'Chat::send');
$routes->get('chat/fetch/(:num)', 'Chat::fetch/$1');
$routes->get('chat/unread-count', 'Chat::unreadCount', ['filter' => 'authGuard']);
$routes->get('chat/inbox', 'Chat::inbox', ['filter' => 'authGuard']);

//forgot-password-----
$routes->get('forgot-password', 'Auth::forgotPassword');
$routes->post('forgot-password', 'Auth::sendOtp');
$routes->get('reset-password', 'Auth::resetForm');
$routes->post('update-password', 'Auth::updatePassword');
$routes->get('resetFormpassword/', 'Auth::resetFormpassword');

//-----profile creation----
$routes->get('profile', 'Profile::view', ['filter' => 'authGuard']);
$routes->get('profile/edit', 'Profile::edit', ['filter' => 'authGuard']);
$routes->post('profile/update', 'Profile::update', ['filter' => 'authGuard']);


////------SuperAdmin-------
$routes->get('admin/login', 'AdminAuth::login');
$routes->post('admin/login', 'AdminAuth::postLogin');
$routes->get('admin/logout', 'AdminAuth::logout');
//$routes->get('admin/dashboard', 'AdminDashboard::index', ['filter' => 'adminGuard']);
$routes->get('admin/dashboard/(:any)', 'AdminDashboard::index/$1', ['filter' => 'adminGuard']);

$routes->get('admin/users', 'AdminDashboard::UserIndex', ['filter' => 'adminGuard']);
$routes->get('admin/users/delete/(:num)', 'AdminDashboard::delete/$1', ['filter' => 'adminGuard']);
$routes->get('admin/jobs', 'AdminDashboard::JobsIndex', ['filter' => 'adminGuard']);
$routes->get('admin/jobs/delete/(:num)', 'AdminDashboard::DeleteJobs/$1', ['filter' => 'adminGuard']);
$routes->get('admin/applications', 'AdminDashboard::ApplicationIndex', ['filter' => 'adminGuard']);
$routes->get('admin/applications/delete/(:num)', 'AdminDashboard::ApplicationsDelete/$1', ['filter' => 'adminGuard']);

$routes->get('admin/companies', 'CompanyController::index', ['filter' => 'adminGuard']);
$routes->get('admin/companies/create', 'CompanyController::create', ['filter' => 'adminGuard']);
$routes->post('admin/companies/store', 'CompanyController::store', ['filter' => 'adminGuard']);
$routes->get('admin/companies/edit/(:num)', 'CompanyController::edit/$1', ['filter' => 'adminGuard']);
$routes->post('admin/companies/update/(:num)', 'CompanyController::update/$1', ['filter' => 'adminGuard']);
$routes->get('admin/companies/delete/(:num)', 'CompanyController::delete/$1', ['filter' => 'adminGuard']);
$routes->get('admin/companies/search', 'CompanyController::search', ['filter' => 'adminGuard']); 

/////-----Api--------
$routes->group('api', ['namespace' => 'App\Controllers\Api'], function($routes) {
    
    // Auth
    $routes->post('login', 'AuthController::login');
    $routes->post('logout', 'AuthController::logout');

    // Protected routes
    $routes->group('', ['filter' => 'authGuard'], function($routes) {
        $routes->resource('jobs');
        
        // Applications
        $routes->resource('applications');
        $routes->get('applications/user/(:num)', 'ApplicationController::user/$1');
        $routes->get('applications/job/(:num)', 'ApplicationController::job/$1');

        // Chat
        $routes->post('chat/send', 'ChatController::send');
        $routes->get('chat/conversation/(:num)/(:num)', 'ChatController::conversation/$1');
        $routes->get('chat/unread/(:num)', 'ChatController::unread/$1');
    });
});
















