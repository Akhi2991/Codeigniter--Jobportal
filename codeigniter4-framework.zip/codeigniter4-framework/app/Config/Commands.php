<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Commands  extends BaseConfig
{
   /**
     * List of command classes to register.
     * @var string[]
     */
    public $commands = [
            \App\Commands\SendJobAlerts::class,
    ];  
}
