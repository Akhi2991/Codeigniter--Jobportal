<?php 
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\JobModel;
use App\Models\UserModel;

class SendJobAlerts extends BaseCommand
{
    protected $group       = 'Alerts';
    protected $name        = 'send:jobalerts';
    protected $description = 'Send job alert emails to subscribed users';

    public function run(array $params)
    {
        $db = \Config\Database::connect();
        $alertQuery = $db->table('job_alerts')->get()->getResult();

        $jobModel = new JobModel();
        $userModel = new UserModel();

        foreach ($alertQuery as $alert) {
            $query = $jobModel->where('status', 1)
                              ->where('expires_at >=', date('Y-m-d'));

            if ($alert->keyword) {
                $query->groupStart()
                      ->like('title', $alert->keyword)
                      ->orLike('description', $alert->keyword)
                      ->groupEnd();
            }

            if ($alert->category_id) {
                $query->where('category_id', $alert->category_id);
            }

            $newJobs = $query->where('created_at >=', date('Y-m-d', strtotime('-1 day')))
                             ->findAll();

            if ($newJobs) {
                $user = $userModel->find($alert->user_id);
                $jobList = "";

                foreach ($newJobs as $job) {
                    $jobList .= "- {$job['title']} at {$job['location']}\n";
                }

                $emailService = \Config\Services::email();
                $emailService->setTo($user['email']);
                $emailService->setSubject('New Job Matches for You');
                $emailService->setMessage($htmlMessage); // OR setHTMLMessage()
                $sent = $emailService->send();

                if (!$sent) {
                    log_message('error', 'Email failed to ' . $user['email']);
                    log_message('error', $emailService->printDebugger(['headers', 'subject', 'body']));
                }

            }
        }

        CLI::write('Job alerts sent.');
    }
}
