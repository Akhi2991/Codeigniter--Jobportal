<?php namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use App\Models\JobModel;

class ExpireJobs extends BaseCommand
{
    protected $group       = 'Maintenance';
    protected $name        = 'jobs:expire';
    protected $description = 'Marks expired jobs as expired.';

    public function run(array $params)
    {
        $model = new JobModel();
        $today = date('Y-m-d');

        $expired = $model->where('expires_at <', $today)
                         ->where('status', 'active')
                         ->set(['status' => 'expired'])
                         ->update();

        echo "Jobs expired: $expired\n";
    }
}
