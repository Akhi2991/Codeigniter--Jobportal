<?php

namespace App\Controllers;
use App\Models\JobModel;
use App\Models\companyModel;

class Jobportal extends BaseController
{
    public function index()
    {
        $jobModel = new \App\Models\JobModel();
        $companyModel = new \App\Models\companyModel();

        $today = date('Y-m-d'); // current date

        $trendingJobs = $jobModel->where('status', 1)
                             ->where('expires_at >=', $today) // exclude expired
                             ->orderBy('created_at', 'DESC')
                             ->limit(5)
                             ->findAll();
                             //print_r( $trendingJobs);exit();
         if (!$trendingJobs) {
        // If not found or expired
        return redirect()->to('/jobs')->with('error', 'Job not found or expired.');
        }
        $topCompanies =  $companyModel->orderBy('created_at', 'DESC')->findAll();
        return view('jobportal/index', ['jobs' => $trendingJobs,'topCompanies' => $topCompanies]);
    }
}
