<?php

namespace App\Controllers;

use App\Models\userModel;

class AdminAuth extends BaseController
{
    public function login()
    {
        return view('admin/login');
    }

    public function postLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $redirect = $this->request->getPost('redirect');


        $userModel = new userModel();
        $admin =  $userModel->where('email', $email)->where('role','admin')->first();

        if ($admin && password_verify($password, $admin['password'])) {
            session()->set([
                'admin_id' => $admin['id'],
                'admin_name' => $admin['name'],
                'isAdminLoggedIn' => true
            ]);
            if (!empty($redirect)) {
            $decodedUrl = base64_decode($redirect);
            return redirect()->to($decodedUrl);
        }
             // Encode user ID for URL
           $encodedId = base64_encode($admin['id']);

            return redirect()->to('admin/dashboard/' . $encodedId);
        }

        return redirect()->back()->with('error', 'Invalid credentials.');
    }

    public function logout()
    {
     session()->destroy();
     return redirect()->to('/admin/login')->with('success', 'Logged out successfully');
    }
}
