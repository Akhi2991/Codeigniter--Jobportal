<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\JobModel;

class Jobs extends ResourceController
{
    protected $modelName = JobModel::class;
    protected $format    = 'json';

    // GET /api/jobs
    public function index()
    {
        $jobs = $this->model->where('status', 'active')->findAll();
        return $this->respond($jobs);
    }

    // GET /api/jobs/{id}
    public function show($id = null)
    {
        $job = $this->model->find($id);
        if (!$job) {
            return $this->failNotFound("Job not found");
        }
        return $this->respond($job);
    }

    // POST /api/jobs
    public function create()
    {
        $data = $this->request->getJSON(true);

        if (!$this->model->insert($data)) {
            return $this->failValidationErrors($this->model->errors());
        }

        return $this->respondCreated([
            'message' => 'Job created successfully',
            'id' => $this->model->getInsertID()
        ]);
    }

    // PUT /api/jobs/{id}
    public function update($id = null)
    {
        $data = $this->request->getJSON(true);

        if (!$this->model->update($id, $data)) {
            return $this->failValidationErrors($this->model->errors());
        }

        return $this->respond([
            'message' => 'Job updated successfully'
        ]);
    }

    // DELETE /api/jobs/{id}
    public function delete($id = null)
    {
        if (!$this->model->delete($id)) {
            return $this->failNotFound("Job not found or already deleted");
        }

        return $this->respondDeleted([
            'message' => 'Job deleted successfully'
        ]);
    }
}
