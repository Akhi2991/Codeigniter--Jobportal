<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\ApplicationModel;

class ApplicationController extends ResourceController
{
    protected $modelName = ApplicationModel::class;
    protected $format    = 'json';

    // ✅ Apply to a job
    public function create()
    {
        $data = $this->request->getJSON(true);

        if (!$this->model->insert($data)) {
            return $this->fail($this->model->errors());
        }

        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Application submitted successfully',
            'application_id' => $this->model->getInsertID()
        ]);
    }

    // ✅ Get all applications for a user (job seeker)
    public function user($userId = null)
    {
        $apps = $this->model->where('user_id', $userId)->findAll();
        return $this->respond($apps);
    }

    // ✅ Get all applicants for a job (employer)
    public function job($jobId = null)
    {
        $apps = $this->model->where('job_id', $jobId)->findAll();
        return $this->respond($apps);
    }

    // ✅ Update application status (accepted/rejected)
    public function update($id = null)
    {
        $data = $this->request->getJSON(true);

        if (!$this->model->update($id, $data)) {
            return $this->fail($this->model->errors());
        }

        return $this->respondUpdated(['status' => 'success', 'message' => 'Application updated']);
    }
}
