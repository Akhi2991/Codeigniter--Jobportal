<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;

class AuthController extends ResourceController
{
    protected $format = 'json';

    public function login()
    {
        $data = $this->request->getJSON(true);
        $userModel = new UserModel();

        $user = $userModel->where('email', $data['email'])->first();

        if (!$user || !password_verify($data['password'], $user['password'])) {
            return $this->failUnauthorized('Invalid login credentials');
        }

        // Store session
        $session = session();
        $session->set([
            'user_id' => $user['id'],
            'role'    => $user['role'], // seeker/employer/admin
            'logged_in' => true
        ]);

        return $this->respond([
            'status' => 'success',
            'message' => 'Login successful',
            'session_id' => session_id() // important for API client
        ]);
    }

    public function logout()
    {
        session()->destroy();
        return $this->respond(['status' => 'success', 'message' => 'Logged out']);
    }
}
