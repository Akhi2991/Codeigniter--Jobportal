<?php

namespace App\Controllers;

use App\Models\UserModel;

use CodeIgniter\Controller;

class Profile extends BaseController
{
     protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function resume(){
        $userId = session()->get('user_id');
        $userModel = new UserModel();
        $user = $userModel->find($userId);
        return view('profile/resume', ['user' => $user]);
    }
    public function ReplaceResume()
    {
        $userId = session()->get('user_id');
        $userModel = new UserModel();
        $user = $userModel->find($userId);

        //if ($this->request->getMethod() === 'post') {
            $file = $this->request->getFile('resume');
            $newName = null;

            if ($file && $file->isValid() && !$file->hasMoved()) {
                $newName = $file->getRandomName();

                // Optional: delete old resume
                if ($user['resume'] && file_exists('uploads/resumes/' . $user['resume'])) {
                    unlink('uploads/resumes/' . $user['resume']);
                }

                $file->move('uploads/resumes/', $newName);

                $userModel->update($userId, ['resume' => $newName]);

                return redirect()->to('profile/resume')->with('success', 'Resume updated successfully.');
            }

            return view('profile/resume', ['user' => $user, 'error' => 'Upload failed.']);
        /*}*/

        //return view('profile/resume', ['user' => $user]);
    }
     public function view()
    {
        $user = $this->userModel->find(session()->get('user_id'));
        return view('profile/view', ['user' => $user]);
    }

    public function edit()
    {
        $user = $this->userModel->find(session()->get('user_id'));
        return view('profile/edit', ['user' => $user]);
    }

    public function update()
    {
         $userId = session()->get('user_id');
         $user = $this->userModel->find($userId);

        $data = [
            'name'  => $this->request->getPost('name'),
            'phone' => $this->request->getPost('phone'),
            'bio'   => $this->request->getPost('bio'),
        ];

        if ($img = $this->request->getFile('profile_image')) {
          if ($img->isValid() && !$img->hasMoved()) {
                $newName = $img->getRandomName();
                $img->move('uploads/profile_pics', $newName);
                $data['profile_pic'] = $newName;

                // Optional: Delete old image if exists and not default
                if (!empty($user['profile_pic']) && $user['profile_pic'] !== 'default.png') {
                    @unlink(FCPATH . 'uploads/profile_pics/' . $user['profile_pic']);
                }
         }
       }
        $this->userModel->update($userId, $data);

        return redirect()->to('profile')->with('success', 'Profile updated successfully.');
    }


}
