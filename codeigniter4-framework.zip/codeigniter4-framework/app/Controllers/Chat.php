<?php

namespace App\Controllers;

use App\Models\MessageModel;

class Chat extends BaseController
{
    public function index($userId = null)
    {
        return view('chat/index', ['recipient_id' => $userId]);
    }

    public function send()
    {
        $msgModel = new MessageModel();
        $msgModel->save([
            'sender_id'   => session()->get('user_id'),
            'receiver_id' => $this->request->getPost('receiver_id'),
            'message'     => $this->request->getPost('message'),
        ]);

        return $this->response->setJSON(['status' => 'sent']);
    }

    public function fetch($userId)
    {

        $msgModel = new MessageModel();

        $senderId = session()->get('user_id');

         // Mark all received messages from the other user as read
        $msgModel
        ->where('sender_id', $userId)
        ->where('receiver_id',  $senderId)
        ->set(['is_read' => 1])
        ->update();

        $messages = $msgModel->where("(sender_id = $senderId AND receiver_id = $userId) OR (sender_id = $userId AND receiver_id = $senderId)")
                             ->orderBy('created_at', 'ASC')
                             ->findAll();

        return $this->response->setJSON($messages);
    }

    public function unreadCount()
  {
    $msgModel = new MessageModel();
    $userId = session()->get('user_id');

    $count =$msgModel
        ->where('receiver_id', $userId)
        ->where('is_read', 0)
        ->countAllResults();

    return $this->response->setJSON(['count' => $count]);
 }

 public function inbox()
{
   
    $userId = session()->get('user_id');
    $msgModel = new MessageModel();

    // Get all unique users who sent or received messages with current user
    $builder = $msgModel->builder();
    $builder->select('users.id, users.name, users.email')
            ->distinct()
            ->join('users', "users.id = messages.sender_id OR users.id = messages.receiver_id")
            ->where("messages.sender_id = $userId OR messages.receiver_id = $userId")
            ->where("users.id != $userId"); // exclude self

    $contacts = $builder->get()->getResultArray();

    return view('chat/inbox', ['contacts' => $contacts]);
}


}
