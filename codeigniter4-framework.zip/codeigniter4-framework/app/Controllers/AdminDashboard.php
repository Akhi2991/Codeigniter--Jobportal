<?php

namespace App\Controllers;

use App\Models\userModel;

use App\Models\JobModel;

use App\Models\ApplicationModel;

use CodeIgniter\I18n\Time;


class AdminDashboard extends BaseController
{
    protected $userModel;
    protected $jobModel;
    protected $appModel;

    public function __construct()
    {
        $this->appModel = new ApplicationModel();
        $this->jobModel = new JobModel();
        $this->userModel = new UserModel();
    }
    public function index($encodedId = null)
    { 
        if ($encodedId) {
        $adminId = base64_decode($encodedId);
         if (session()->get('admin_id') != $adminId) {
            return redirect()->to('admin/login')->with('error', 'Unauthorized access.');
        }
        $now = Time::now();
        $startOfWeek = Time::parse('last monday')->setTime(0, 0); 
        $startOfMonth = Time::today()->setDate($now->getYear(), $now->getMonth(), 1)->setTime(0, 0); 

        $totalApplications = $this->appModel->countAllResults();
        $weeklyApplications = $this->appModel
            ->where('created_at >=', $startOfWeek->toDateTimeString())
            ->countAllResults();

        $monthlyApplications = $this->appModel
            ->where('created_at >=', $startOfMonth->toDateTimeString())
            ->countAllResults();

            $dailyCounts = [];
            $labels = [];

        for ($i = 6; $i >= 0; $i--) {
            $day = Time::today()->subDays($i);
            $count = $this->appModel
                        ->where('DATE(created_at)', $day->toDateString())
                        ->countAllResults();

            $labels[] = $day->toLocalizedString('MMM d');  // e.g., Jun 28
            $dailyCounts[] = $count;
        }

        $data = [
            'total'   =>   $totalApplications,
            'weekly'  =>   $weeklyApplications,
            'monthly' =>   $monthlyApplications,
            'labels'  =>   $labels,
            'dataPoints'=> $dailyCounts,
        ];
        return view('admin/dashboard',$data);
      }
    }  

    public function UserIndex()
    {
        $role = $this->request->getGet('role');

        $query = $this->userModel->orderBy('created_at', 'DESC');
        if ($role) {
            $query->where('role', $role);
        }

        $data = [
            'title' => 'Manage Users',
            'users' => $query->findAll(),
            'selectedRole' => $role
        ];

        return view('admin/users', $data);
    }

    public function delete($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $this->userModel->delete($id);
        return redirect()->back()->with('success', 'User deleted successfully.');
    } 
     public function JobsIndex()
    {
        $jobs = $this->jobModel
            ->select('jobs.*, users.name as employer_name')
            ->join('users', 'users.id = jobs.employer_id', 'left')
            ->orderBy('jobs.created_at', 'DESC')
            ->findAll();

        return view('admin/jobs', ['jobs' => $jobs]);
    }

    public function DeleteJobs($id)
    {
        $job = $this->jobModel->find($id);
        if (!$job) {
            return redirect()->back()->with('error', 'Job not found.');
        }

        $this->jobModel->delete($id);
        return redirect()->back()->with('success', 'Job deleted successfully.');
    }
     public function ApplicationIndex()
    {
        $applications = $this->appModel
            ->select('applications.*, users.name as applicant_name, users.email, jobs.title as job_title')
            ->join('users', 'users.id = applications.user_id')
            ->join('jobs', 'jobs.id = applications.job_id')
            ->orderBy('applications.created_at', 'DESC')
            ->findAll();

        return view('admin/application', ['applications' => $applications]);
    }

    public function ApplicationsDelete($id)
    {
        $app = $this->appModel->find($id);

        if (!$app) {
            return redirect()->back()->with('error', 'Application not found.');
        }

        $this->appModel->delete($id);
        return redirect()->back()->with('success', 'Application deleted successfully.');
    }
}
