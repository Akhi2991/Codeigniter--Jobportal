<?php

namespace App\Controllers;
use App\Models\UserModel;
use App\Controllers\BaseController;
use CodeIgniter\Email\Email;
use CodeIgniter\I18n\Time;
use CodeIgniter\Controller;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once APPPATH . '../phpmailer/PHPMailer.php';
require_once APPPATH . '../phpmailer/SMTP.php';
require_once APPPATH . '../phpmailer/Exception.php';
class Auth extends BaseController
{
    protected $userModel;
    //protected $request;
    public function __construct()
    {
        // Load the UserModel
        $this->userModel = new UserModel();
        //$this->request = \Config\Services::request();
    }
    public function login()
    {
     return view('auth/login');
    }

   public function sendOtpToPhone(){
    $phone = $this->request->getPost('phone');
    $user = $this->userModel->where('phone', $phone)->first();
    //print_r($user);exit;

    if (!$user) {
        return redirect()->back()->with('error', 'Phone number not found.');
    }

    $otp = rand(100000, 999999);

    // Save OTP to DB
    $this->userModel->update($user['id'], [
        'otp' => $otp,
        'otp_created_at' => date('Y-m-d H:i:s'),
    ]);

    $fields = array(
    "sender_id" => "JOBPRT", // Replace with your approved sender ID
    "message" => "Login for otp is",    // Replace with your approved DLT message ID
    "variables_values" => $otp,
    "route" => "dlt",
    "numbers" => $phone
);

   /* // Send via Fast2SMS
    $apiKey = 'OiZaofxl6mMggqkBRQN2Z4uo3G4qBGWr1J4zbRmmII6u9bmPKML5lU5YAVls';
    $msg = urlencode("Your OTP for login is: $otp");
    $url = "https://www.fast2sms.com/dev/bulkV2?authorization=$apiKey&route=v3&sender_id=TXTIND&message=$msg&language=english&flash=0&numbers=$phone";

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['cache-control: no-cache'],
    ]);
    $response = curl_exec($curl);
    curl_close($curl);*/

    $curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($fields),
    CURLOPT_HTTPHEADER => array(
        "authorization: StxggrlLm4HUzxdxNx4vw0M6ufg6RrjPdBANND2c4n25ybKBbngnwMvy0UlN", // Replace with your actual Fast2SMS API key
        "accept: */*",
        "cache-control: no-cache",
        "content-type: application/json"
    ),
));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo $response;
    }

    return view('auth/verify_otp', ['phone' => $phone]);
   }

   public function verifyOtp()
{
    $phone = $this->request->getPost('phone');
    $otp = $this->request->getPost('otp');

    $user = $this->userModel->where('phone', $phone)->first();

    if (!$user || $user['otp'] != $otp) {
        return redirect()->back()->with('error', 'Invalid OTP.');
    }

    // Check if OTP is expired (5 mins)
    $created = strtotime($user['otp_created_at']);
    if (time() - $created > 300) {
        return redirect()->to('auth/login')->with('error', 'OTP expired. Please try again.');
    }

    // Login user
    session()->set([
        'user_id' => $user['id'],
        'user_name' => $user['name'],
        'user_email' => $user['email'],
        'user_role' => $user['role'],
        'isLoggedIn' => true,
        'last_activity' => time(),
    ]);

    return redirect()->to('/dashboard');
}

public function postlogin()
{
    helper(['form']);

    // 1. Validate inputs including captcha field
    $rules = [
        'email'                => 'required|valid_email',
        'password'             => 'required|min_length[6]|max_length[200]',
        'g-recaptcha-response' => 'required'
    ];

    if (! $this->validate($rules)) {
        return view('auth/login', [
            'validation' => $this->validator
        ]);
    }

    // 2. Verify Google reCAPTCHA
    $captcha = $this->request->getPost('g-recaptcha-response');
    $secretKey = '6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe'; // Replace with your real secret key
    $verifyResponse = file_get_contents(
        "https://www.google.com/recaptcha/api/siteverify?secret={$secretKey}&response={$captcha}"
    );
    $responseData = json_decode($verifyResponse);

    if (! $responseData->success) {
        return redirect()->back()->withInput()->with('error', 'Captcha verification failed.');
    }else{

    // 3. Check credentials
    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');
    $user = $this->userModel->getUserByEmail($email); 
    $redirect = $this->request->getPost('redirect');

    if ($user && password_verify($password, $user['password'])) {
        session()->set([
            'user_id'       => $user['id'],
            'user_name'     => $user['name'],
            'user_email'    => $user['email'],
            'user_role'     => $user['role'],
            'user_profile'  => $user['profile_pic'],
            'isLoggedIn'    => true,
            'last_activity' => time(),
        ]);
         // If there's a base64 redirect URL, decode and redirect
        if (!empty($redirect)) {
            $decodedUrl = base64_decode($redirect);
            return redirect()->to($decodedUrl);
        }
             // Encode user ID for URL
        $encodedId = base64_encode($user['id']);
        //$encodedId = rtrim(strtr(base64_encode($user['id']), '+/', '-_'), '=');
        //$userId = base64_decode(strtr($encodedId, '-_', '+/'));
        return redirect()->to('dashboard/' . $encodedId);

        //return redirect()->to('/dashboard');
    }
    else{
         //return redirect()->back()->withInput()->with('error', 'Invalid email or password.');
         return redirect()->to('auth/login')->with('error', 'Invalid email or password.');
    }}
}

    public function register()
    {
     return view('auth/register');
    }
    public function postregister(){
         //return view('auth/register');
     /*if ($this->request->getMethod() === 'post') {*/
         helper(['form']);
        /* set rules validation form */
        $rules = [
            'name'          => 'required|min_length[3]|max_length[20]',
            'email'         => 'required|min_length[6]|max_length[50]|valid_email|is_unique[users.email]',
            'password'      => 'required|min_length[6]|max_length[200]',
            //'confpassword'  => 'matches[password]'
        ];
        //if ($this->request->getMethod() === 'post') { 
            if($this->validate($rules)){
                $data = [
                    'name'     => $this->request->getPost('name'),
                    'email'    => $this->request->getPost('email'),
                    'phone'    => $this->request->getPost('phone'),
                    'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                    'role'     => $this->request->getPost('role'),
                ];

                // Check if email exists
                if ($this->userModel->where('email', $data['email'])->first()) {
                    return view('auth/register', ['error' => 'Email already exists']);
                }

                $this->userModel->save($data);
                return redirect()->to('auth/login')->with('success', 'Account created! Please login.');
            /*}*/
             }
            else {
                return view('auth/register', [
                    'validation' => $this->validator
                ]);
            }
      /*} 
      else{
           return view('auth/register');
      }*/ 
  }


    public function logout()
    {
        session()->destroy();
        return redirect()->to('auth/login')->with('successlogout','You have successfully logged out.');
    }


    public function forgotPassword()
{
    return view('auth/forgot_password');
}

public function sendOtp()
{
    $email = $this->request->getPost('email');

    $user = (new UserModel())->where('email', $email)->first();
    if (!$user) {
        return redirect()->back()->with('error', 'Email not found.');
    }

    $otp = rand(100000, 999999);

    // Store OTP
    $db = \Config\Database::connect();
    $db->table('password_resets')->insert([
        'email' => $email,
        'otp' => $otp,
    ]);

   /* // Send Email
    $emailService = \Config\Services::email();
    $emailService->setTo($email);
    $emailService->setSubject('Your OTP for Password Reset');
    $emailService->setMessage("Your OTP is: $otp");
    $emailService->send();
    $success = $emailService->send();

    if(!$success) {
    log_message('error', $emailService->printDebugger(['headers', 'subject', 'body']));
    //return redirect()->back()->with('error', 'Email sending failed. Check logs.');
   }*/

     $mail = new PHPMailer(true);
    // $mail->SMTPDebug = 2; // Or 3 for more details

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'akhiljose896@gmail.com';
            $mail->Password = 'wlbk vzkn bjyk byvh';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Optional for dev only:
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true,
                ]
            ];
                    
            $mail->setFrom('akhiljose896@gmail.com', 'Jobportal');
            $mail->addAddress($email); // To email
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP';
            $mail->Body    = 'Your OTP is: '. $otp;

            $mail->send();
           // echo 'OTP Sent!';

        } catch (Exception $e) {
            echo "Mailer Error: {$mail->ErrorInfo}";
        }
        return redirect()->to('/resetFormpassword?email=' . urlencode($email))
                 ->with('success', 'OTP sent successfully.');


    //return view('auth/reset_password', ['email' => $email]);
}

public function resetFormpassword(){
   $email = $this->request->getGet('email'); // from query string
   return view('auth/reset_password', ['email' => $email]); 
}

public function resetForm()
{
    return redirect()->to('forgot-password');
}

public function updatePassword()
{
    $email = $this->request->getPost('email');
    //print_r( $email);exit();
    $otp = $this->request->getPost('otp');
    $newPassword = $this->request->getPost('password');

    $db = \Config\Database::connect();
    $record = $db->table('password_resets')->where(['email' => $email, 'otp' => $otp])->get()->getRow();

    if (!$record) {
        return redirect()->back()->with('error', 'Invalid OTP.');
    }

    // ✅ Check if OTP is expired (older than 5 minutes)
    $otpTime = strtotime($record->created_at);
    if (time() - $otpTime > 500) {  // 300 seconds = 5 minutes
        return redirect()->back()->with('error', 'OTP has expired. Please request a new one.');
    }

    // Optional: Expire OTP after 15 minutes
    $userModel = new UserModel();
    $user = $userModel->where('email', $email)->first();

    if ($user) {
        $userModel->update($user['id'], ['password' => password_hash($newPassword, PASSWORD_DEFAULT)]);
        $db->table('password_resets')->where('email', $email)->delete(); // clear OTP
        return redirect()->to('auth/login')->with('success', 'Password updated successfully.');
    }

    return redirect()->back()->with('error', 'Something went wrong.');
}

}

