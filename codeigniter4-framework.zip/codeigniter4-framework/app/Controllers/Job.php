<?php

namespace App\Controllers;
use App\Models\JobTagsModel;
use App\Models\JobModel;
use App\Models\ApplicationModel;
use App\Models\NotificationModel;
use App\Models\SavedJobModel;
use App\Models\JobCategoryModel;
use App\Models\JobTagsMapModel;
use App\Models\UserModel;
use App\Models\InterviewModel;
use App\Models\MessageModel;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once APPPATH . '../phpmailer/PHPMailer.php';
require_once APPPATH . '../phpmailer/SMTP.php';
require_once APPPATH . '../phpmailer/Exception.php';


class Job extends BaseController
{
    protected $jobModel;
    protected $applicationModel;
    protected $categoryModel;
    protected $tagModel;

    public function __construct()
    {
        $this->jobModel = new JobModel();
        $this->applicationModel = new ApplicationModel();
        $this->categoryModel = new JobCategoryModel();
        $this->tagModel = new JobTagsModel();
    }
    public function getjobs(){

        $categoryModel = new JobCategoryModel();
        $tagModel = new JobTagsModel();
        $data = [
            'categories' => $categoryModel->findAll(),
            'tags'       => $tagModel->findAll()
        ];

        return view('jobs/post',$data);
    }

    public function post()
    {
       helper(['form']);
        /* set rules validation form */
        $rules = [
            'title'       => 'required',
            'description' => 'required',
            'location'    => 'required',
            'salary'      => 'required',

        ];
        if($this->validate($rules)){
       /* if ($this->request->getMethod() === 'post') {*/
            $newJobCatId= $this->request->getPost('category_id');
            $this->jobModel->save([
                'employer_id' => session()->get('user_id'),
                'title'       => $this->request->getPost('title'),
                'description' => $this->request->getPost('description'),
                'location'    => $this->request->getPost('location'),
                'salary'      => $this->request->getPost('salary'),
                'expires_at' => $this->request->getPost('expires_at'),
                'status'     => 'active',
                'category_id'=> $this->request->getPost('category_id'),
                'experience_level' => $this->request->getPost('experience_level'),
                'job_type'         => $this->request->getPost('job_type'),
                'is_remote'        => $this->request->getPost('is_remote')
            ]);

            // 2. Get the new job ID
            $newJobId = $this->jobModel->getInsertID();

            // 3. Save job-tag mapping
            $tagMapModel = new \App\Models\JobTagsMapModel();

             if ($this->request->getPost('tags')) {
            foreach ($this->request->getPost('tags') as $tagId) {
                $tagMapModel->save([
                    'job_id' => $newJobId,
                    'tag_id' => $tagId
                ]);
            }
          }

            return redirect()->to('jobs/manage')->with('success', 'Job posted successfully!');
        }

        return view('jobs/post');
    }

    public function manage()
    {
        //$jobs = $this->jobModel->where('employer_id', session()->get('user_id'))->findAll();
       // print_r( $jobs);exit();
         $db = \Config\Database::connect();

        // Get jobs with category name
        $builder = $db->table('jobs');
        $builder->select('jobs.*,job_categories.name as category_name');
        $builder->join('job_categories', 'job_categories.id = jobs.category_id', 'left')->where('employer_id', session()->get('user_id'));
        $builder->orderBy('jobs.created_at', 'DESC');
        $jobs = $builder->get()->getResultArray();
        //print_r($jobs);exit();

        // Get tags for each job
        foreach ($jobs as &$job) {
            $tagBuilder = $db->table('job_tag_map')
                ->select('job_tags.name')
                ->join('job_tags', 'job_tags.id = job_tag_map.tag_id')
                ->where('job_tag_map.job_id', $job['id']);

            $tags = $tagBuilder->get()->getResultArray();
            $job['tags'] = array_column($tags, 'name');
        }

        return view('jobs/manage', ['jobs' => $jobs]);
    }

    public function edit($id)
   {
    $job = $this->jobModel->find($id);

    if (!$job || $job['employer_id'] != session()->get('user_id')) {
        return redirect()->to('/dashboard')->with('error', 'Unauthorized or job not found.');
    }

     
     // Get associated tag IDs
    $jobModel = new JobModel();
    $categoryModel = new JobCategoryModel();
    $tagModel = new JobTagsModel();
    $tagMapModel = new JobTagsMapModel();
    $tagMap = $tagMapModel->where('job_id', $id)->findAll();
    $selectedTags = array_column($tagMap, 'tag_id');
    //print_r( $selectedTags);exit();

     return view('jobs/edit',
      ['job' => $job,
       'categories' =>  $categoryModel->findall(),
        'tags' => $tagModel->findAll(),
        'selectedTags' => $selectedTags,

      ]);
}
 public function update($id){
    $job = $this->jobModel->find($id);
    //print_r($job);exit;

    if (!$job || $job['employer_id'] != session()->get('user_id')) {
        return redirect()->to('/dashboard')->with('error', 'Unauthorized or job not found.');
    }

    $this->jobModel->update($id, [
        'title'       => $this->request->getPost('title'),
        'description' => $this->request->getPost('description'),
        'location'    => $this->request->getPost('location'),
        'salary'      => $this->request->getPost('salary'),
        'expires_at'      => $this->request->getPost('expires_at'),
        'category_id' => $this->request->getPost('category_id'),
        'experience_level' => $this->request->getPost('experience_level'),
        'job_type'         => $this->request->getPost('job_type'),
        'is_remote'        => $this->request->getPost('is_remote')

    ]);

      // Update tag mappings
    $tagMapModel = new JobTagsMapModel();
    $tagMapModel->where('job_id', $id)->delete(); // Remove old mappings
    $tags = $this->request->getPost('tags');
    if ($tags) {
        foreach ($tags as $tagId) {
            $tagMapModel->insert([
                'job_id' => $id,
                'tag_id' => $tagId
            ]);
        }
    }

    return redirect()->to('jobs/manage')->with('success', 'Job updated successfully.');
  }

  public function delete($id)
{
    $job = $this->jobModel->find($id);

    if ($job && $job['employer_id'] == session()->get('user_id')) {
        $this->jobModel->delete($id);
        return redirect()->to('jobs/manage')->with('success', 'Job deleted successfully.');
    }
    return redirect()->to('jobs/manage')->with('error', 'Unauthorized or job not found.');
}
  public function list(){
       helper('text');
       $keyword = $this->request->getGet('keyword');
      //print_r( $keyword );
       $location = $this->request->getGet('location');
       $salaryMax = $this->request->getGet('salary');      // numeric
       $salary = $this->request->getGet('salary');
       $type = $this->request->getGet('type');
       $experience= $this->request->getGet('experience');  // string
       $remote    = $this->request->getGet('remote');      // "1" or ""

       $today = date('Y-m-d');

       $query = $this->jobModel->where('expires_at >=', $today)
                            ->where('status', 1)
                            ->orderBy('created_at', 'DESC');
       if ($keyword) {
        $query->groupStart()
              ->like('title', $keyword)
              ->orLike('description', $keyword)
              ->groupEnd();
      }

    if ($location) {
        $query->like('location', $location);
    }

    /*if ($salary) {
        $query->like('salary', $salary);
    }*/

     if ($type) {
        $query->where('type', $type);
    }



        $appliedJobs = [];
        if (session()->get('user_role') === 'user') {
        $applicationModel = new \App\Models\ApplicationModel();
        $applications = $applicationModel->where('user_id', session()->get('user_id'))->findAll();
        $appliedJobs = array_column($applications, 'job_id');
    }
         $data = [
        'title' => 'Browse Jobs',
        'jobs'  => $query->paginate(10),
        'pager' => $this->jobModel->pager,
        'appliedJobs' => $appliedJobs
    ];

    return view('jobs/list', $data);
  }
  public function view($id)
 {
    $job = $this->jobModel->find($id);
    if (!$job) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Job not found.');
    }
      // ✅ Prevent duplicate count using session
    $session = session();
    $viewedJobs = $session->get('viewed_jobs') ?? [];

    if (!in_array($id, $viewedJobs)) {
        // Increment views only once per session per job
        $this->jobModel->set('views', 'views + 1', false)
                       ->where('id', $id)
                       ->update();

        // Mark this job as viewed
        $viewedJobs[] = $id;
        $session->set('viewed_jobs', $viewedJobs);
    }
    $hasApplied = false;
    if(session()->get('isLoggedIn') && session()->get('user_role') === 'user') {
        $applicationModel = new \App\Models\ApplicationModel();
        $hasApplied = $applicationModel
            ->where('job_id', $id)
            ->where('user_id', session()->get('user_id'))
            ->first() ? true : false;
        return view('jobs/view', [
        'job'        => $job,
        'hasApplied' => $hasApplied
    ]);}

   
}
// Show apply form
public function apply($jobId)
{
    $job = $this->jobModel->find($jobId);
    if (!$job) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Job not found.');
    }
    return view('jobs/apply', ['job' => $job]);
}
public function submitApplication($jobId){
    $model = new ApplicationModel();
    $notifModel = new \App\Models\NotificationModel();
    $jobModel = new \App\Models\JobModel();

    $job = $jobModel->find($jobId);
    if (!$job) {
        return redirect()->to('/jobs')->with('error', 'Job not found.');
    }
     // Check if already applied
    $existing =  $model
        ->where('job_id', $jobId)
        ->where('user_id', session()->get('user_id'))
        ->first();
    $file = $this->request->getFile('resume');
    $resumeName = null;

    if ($file && $file->isValid() && !$file->hasMoved()) {
        $resumeName = $file->getRandomName();
        $file->move('uploads/resumes/', $resumeName);
    }

    if ($existing) {
        return redirect()->to('jobs/view/' . $jobId)
            ->with('error', 'You have already applied for this job.');
    }

    $model->save([
        'job_id'       => $jobId,
        'user_id'      => session()->get('user_id'),
        'coverletter' => $this->request->getPost('cover_letter'),
         'resume'       => $resumeName
    ]);
     // Send notification to employer
    $employerId = $job['employer_id'];
    $jobTitle = $job['title'];
    $notifModel->save([
        'user_id' => $employerId,
        'job_id'  =>$jobId,
        'message' => session()->get('user_name') . ' applied for your job: ' . $jobTitle,
        'link'    => site_url('jobs/applicants') // ✅ link to the job page
    ]);
    return redirect()->to('/applications')->with('success', 'Application submitted!'); 
}
// Job seeker: view application history
public function myApplications()
{
    $model = new ApplicationModel();
    $data['applications'] = $model
        ->select('applications.*, jobs.title, jobs.location')
        ->join('jobs', 'jobs.id = applications.job_id')
        ->where('applications.user_id', session()->get('user_id'))
        ->orderBy('applications.created_at', 'DESC')
        ->findAll();
       // print_r( $data );exit;
    return view('applications/history', $data);
}
// Employer: view applicants for a job
public function viewApplicants($jobId)
{
    if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'employer') {
        return redirect()->to('/dashboard');
    }

    $model = new ApplicationModel();

    $data['applicants'] = $model
        ->select('applications.*, users.name, users.email')
        ->join('users', 'users.id = applications.user_id')
        ->where('applications.job_id', $jobId)
        ->orderBy('applications.created_at', 'DESC')
        ->findAll();

    return view('applications/applicants', $data);
}

public function allApplicants()
{
    if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'employer') {
        return redirect()->to('/dashboard')->with('error', 'Access denied.');
    }

    $applicationModel = new \App\Models\ApplicationModel();
    $jobModel = new \App\Models\JobModel();
    $userModel        = new \App\Models\UserModel();

    // Get employer's jobs
    $employerJobs = $jobModel->select('id')->where('employer_id', session()->get('user_id'))->findAll();

    $jobIds = array_column($employerJobs, 'id');

    if (empty($jobIds)) {
        $data['applicants'] = [];
        return view('applications/all_applicants', $data);
    }

        $data['applicants'] = $applicationModel->withDeleted()
        ->select('applications.*, users.name, users.email, jobs.title')
        ->join('users', 'users.id = applications.user_id')
        ->join('jobs', 'jobs.id = applications.job_id')
        ->whereIn('applications.job_id', $jobIds)
        ->orderBy('applications.created_at', 'DESC')
        ->findAll();

    return view('applications/all_applicants', $data);
}
 public function read($id)
    {
        $model = new NotificationModel();

        $notification = $model->find($id);

        // Optional: Check if it belongs to the current user
        if (!$notification || $notification['user_id'] != session()->get('user_id')) {
            return redirect()->to('/dashboard')->with('error', 'Access denied.');
        }
        // Mark as read
        $model->update($id, ['is_read' => 1]);

        // Redirect to the link
        return redirect()->to($notification['link'] ?? '/dashboard');
    }

   public function updateStatus($id)
{
    $application = $this->applicationModel->find($id);
   // print_r( $application);exit;

    if (!$application) {
        return redirect()->back()->with('error', 'Application not found.');
    }

    $newStatus = $this->request->getPost('status');

    if (!in_array($newStatus, ['Pending', 'Shortlisted', 'Rejected', 'Hired'])) {
        return redirect()->back()->with('error', 'Invalid status.');
    }

    if ($application['status'] === $newStatus) {
        return redirect()->back()->with('info', 'No changes made. Status is already ' . $newStatus);
    }

    // ✅ Update status
    $this->applicationModel->update($id, ['status' => $newStatus]);

     // ✅ Fetch job title from jobs table
    $jobModel = new \App\Models\JobModel();
    $job = $jobModel->find($application['job_id']);
    $jobTitle = $job ? $job['title'] : 'a job';

    // ✅ Notify applicant
    $notifModel = new \App\Models\NotificationModel();
    $notifModel->save([
        'user_id' => $application['user_id'],
         'job_id' => $application['job_id'],
        'message' => 'Your application for "' . $jobTitle . '" was updated to "' . $newStatus . '".',        'is_read' => 0,
        'created_at' => date('Y-m-d H:i:s'),
        'link'   => site_url('/applications') // ✅ link to the application page
    ]);

    return redirect()->back()->with('success', 'Application status updated and applicant notified.');
}


/*public function saveJob($jobId)
{
    if (!session()->get('isLoggedIn')) {
        return redirect()->to('auth/login')->with('error', 'Login required to save jobs.');
    }

    $savedModel = new SavedJobModel();
    $userId = session()->get('user_id');


    // Avoid duplicate saves
    if (!$savedModel->where(['user_id' => $userId, 'job_id' => $jobId])->first()) {
        $savedModel->save(['user_id' => $userId, 'job_id' => $jobId]);
    }

    return redirect()->back()->with('success', 'Job saved!');
}*/

public function toggleSave()
{
    if (!session()->get('isLoggedIn')) {
        return $this->response->setJSON(['success' => false, 'message' => 'Login required.']);
    }

    $jobId = $this->request->getPost('job_id');
    //print_r( $jobId);exit();
    $userId = session()->get('user_id');
    $savedModel = new \App\Models\SavedJobModel();
    $notifModel = new \App\Models\NotificationModel();
    $jobModel = new \App\Models\JobModel();
    $existing = $savedModel->where(['user_id' => $userId, 'job_id' => $jobId])->first();
    if ($existing) {
        $savedModel->where(['user_id' => $userId, 'job_id' => $jobId])->delete();
         $notifModel->where(['user_id' => $userId, 'is_read' => 1, 'job_id' => $jobId])->delete();
        return $this->response->setJSON(['success' => true, 'saved' => false]);
    } else {
          //  Get job title
        $job = $jobModel->find($jobId);
        $jobTitle = $job ? $job['title'] : 'a job';
        $savedModel->save(['user_id' => $userId, 'job_id' => $jobId]);
         // ✅ Notify applicant
        
        $notifModel->save([
            'user_id' =>$userId,
            'job_id'  =>  $jobId ,
            'message' => 'Your application  for "' . esc($jobTitle) . '" saved to saved jobs ', 'is_read' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'link'   => site_url('/jobs/saved')// ✅ link to the saved page,

        ]);

        return $this->response->setJSON(['success' => true, 'saved' => true]);
    }
}


protected function isJobSaved($jobId)
{
    $savedModel = new \App\Models\SavedJobModel();
    return $savedModel->where([
        'user_id' => session()->get('user_id'),
        'job_id'  => $jobId
    ])->first();
}

public function SavedJobs()
{
    $userId = session()->get('user_id');

    $savedModel = new \App\Models\SavedJobModel();
    $appliedModel = new \App\Models\ApplicationModel();
    $jobModel = new \App\Models\JobModel();

    // Get all job IDs the user has applied to
    $appliedJobs = $appliedModel->where('user_id', $userId)->findAll();
    //print_r( $appliedJobs);exit;

    $appliedJobIds = array_column($appliedJobs, 'job_id');
        //print_r(  $appliedJobIds );exit;

    // Get saved jobs, excluding already applied ones
    $savedJobs = $savedModel->where('user_id', $userId)->findAll();
    //print_r($savedJobs);exit;

    $savedJobIds = array_column($savedJobs, 'job_id');
    //print_r($savedJobIds);exit;

    // Filter out jobs the user already applied to
    $filteredIds = array_diff($savedJobIds, $appliedJobIds);
    //print_r($filteredIds);exit;

    $jobs = [];
    if (!empty($filteredIds)) {
        $jobs = $jobModel->whereIn('id', $filteredIds)->findAll();
       // print_r( $jobs);exit;
    }

    return view('jobs/saved', ['jobs' => $jobs]);
}


public function AppliedJobs(){
  
   $userId = session()->get('user_id');

    $applicationModel = new \App\Models\ApplicationModel();
    $jobModel = new \App\Models\JobModel();

    // Get all jobs user applied to
    $applications = $applicationModel->where('user_id', $userId)->where('is_archived',0)->findAll();
    $jobIds = array_column($applications, 'job_id');
    //print_r($jobIds);exit;

    $jobs = [];
    if (!empty($jobIds)) {
        $jobs = $jobModel->whereIn('id', $jobIds)->orderBy('created_at', 'DESC')->findAll();
        //print_r($jobs);exit;
    }

    return view('jobs/AppliedJobs', ['jobs' => $jobs]);
}



 public function subscribe(){
       
       $categoryModel = new JobCategoryModel();
       $data['category']= $categoryModel->findall();

       return view('Jobalert/subscribe',$data);
}
public function postsubscribe()
{
    $userId   = session('user_id');
    $keyword  = $this->request->getPost('keyword');
    $category = $this->request->getPost('category_id');

    $db = \Config\Database::connect();

    // Insert subscription
    $db->table('job_alerts')->insert([
        'user_id'     => $userId,
        'keyword'     => $keyword,
        'category_id' => $category,
    ]);

    // Fetch all job alerts
    $alerts     = $db->table('job_alerts')->get()->getResult();
    $jobModel   = new \App\Models\JobModel();
    $userModel  = new \App\Models\UserModel();

    foreach ($alerts as $alert) {
        $query = $jobModel->where('status', 'active')
                          ->where('expires_at >=', date('Y-m-d'));
                          //dd( $query);exit;
        /* $builder = $jobModel->builder(); // 👈 get the query builder

        $builder->where('status', 'active')
        ->where('expires_at >=', date('Y-m-d'));

        //echo $builder->getCompiledSelect();
        //exit;*/

        if ($alert->keyword) {
            $query->groupStart()
                  ->like('title', $alert->keyword)
                  ->orLike('description', $alert->keyword)
                  ->groupEnd();
        }

        if ($alert->category_id) {
            $query->where('category_id', $alert->category_id);
        }

        $newJobs = $query->where('created_at >=', date('Y-m-d', strtotime('-1 day')))
                         ->findAll();
       // print_r($newJobs);exit;

        if ($newJobs) {
            $user = $userModel->find($alert->user_id);

            if (!$user || !isset($user['email'])) {
                continue;
            }

            $jobList = "<ul>";
            foreach ($newJobs as $job) {
                $jobList .= "<li><strong>{$job['title']}</strong> - {$job['location']}</li>";
            }
            $jobList .= "</ul>";

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'akhiljose896@gmail.com';
                $mail->Password   = 'wlbk vzkn bjyk byvh'; // ✅ Use your app-specific password here
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                // Optional for localhost/dev
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer'       => false,
                        'verify_peer_name'  => false,
                        'allow_self_signed' => true,
                    ]
                ];

                $mail->setFrom('akhiljose896@gmail.com', 'JobPortal');
                $mail->addAddress($user['email'], $user['name']);
                $mail->isHTML(true);
                $mail->Subject = 'Your Daily Job Alerts';
                $mail->Body    = "<p>Hello <strong>{$user['name']}</strong>,</p><p>Here are new jobs matching your alert:</p>{$jobList}";

                $mail->send();
            } catch (Exception $e) {
                log_message('error', 'Mailer Error: ' . $mail->ErrorInfo);
            }
        }
    }

    return redirect()->back()->with('success', 'Subscribed to job alerts!');
}

public function ScheduleInterview($job_id,$applicant_id){
     if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'employer') {
        return redirect()->to('/dashboard');
    }
    $data = [
        'job_id' => $job_id,
        'applicant_id' => $applicant_id
    ];
    return view('interviews/schedule', $data);
}
public function PostScheduleInterview(){

    helper(['form']);

    $interviewModel = new InterviewModel();
    $data = [
        'job_id' => $this->request->getPost('job_id'),
        'applicant_id' => $this->request->getPost('applicant_id'),
        'interview_datetime' => $this->request->getPost('interview_datetime'),
        'mode' => $this->request->getPost('mode'),
        'location' => $this->request->getPost('location'),
        'notes' => $this->request->getPost('notes'),
    ];

    $interviewModel->save($data);

    // OPTIONAL: Send Email
    $applicant = (new UserModel())->find($data['applicant_id']);
     //print_r($applicant);exit;
    // Build ICS content
    $interview = [
        'interview_datetime' => $data['interview_datetime'],
        'location' => $data['location'],
        'notes' => $data['notes']
    ];
    $ics = $this->generateICS($interview);

    $job = (new JobModel())->find($data['job_id']);

    $this->sendInterviewEmail($applicant['email'], $applicant['name'],$job['title'],$data,$ics);

    return redirect()->back()->with('success', 'Interview scheduled & email sent!');
}

private function generateICS($interview)
{
    $start = date('Ymd\THis', strtotime($interview['interview_datetime']));
    $end   = date('Ymd\THis', strtotime('+1 hour', strtotime($interview['interview_datetime'])));

    $ics = "BEGIN:VCALENDAR\r\n";
    $ics .= "VERSION:2.0\r\n";
    $ics .= "PRODID:-//Job Portal//EN\r\n";
    $ics .= "CALSCALE:GREGORIAN\r\n";
    $ics .= "BEGIN:VEVENT\r\n";
    $ics .= "UID:" . uniqid() . "@jobportal.com\r\n";
    $ics .= "DTSTAMP:" . date('Ymd\THis') . "\r\n";
    $ics .= "DTSTART:$start\r\n";
    $ics .= "DTEND:$end\r\n";
    $ics .= "SUMMARY:Interview for Job Application\r\n";
    $ics .= "DESCRIPTION:" . $interview['notes'] . "\r\n";
    $ics .= "LOCATION:" . $interview['location'] . "\r\n";
    $ics .= "END:VEVENT\r\n";
    $ics .= "END:VCALENDAR\r\n";

    return $ics;
}


private function sendInterviewEmail($toEmail, $name, $jobTitle, $data, $ics)
{
    $datetime = date('d M Y H:i A', strtotime($data['interview_datetime']));
    /*$body = "You are invited for an interview for the job: <strong>$jobTitle</strong>.<br><br>
             📅 <strong>Date:</strong> $datetime<br>
             🧭 <strong>Mode:</strong> {$data['mode']}<br>
             📍 <strong>Location:</strong> {$data['location']}<br><br>
             📝 <strong>Notes:</strong><br>{$data['notes']}";

    $email = \Config\Services::email();
    $email->setTo($toEmail);
    $email->setFrom('akhiljose896@gmail.com', 'Job Portal');
    $email->setSubject('Interview Schedule');
    $email->setMessage($body);
    $email->setMailType('html');
    $email->send();*/

    $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'akhiljose896@gmail.com';
                $mail->Password   = 'wlbk vzkn bjyk byvh'; // ✅ Use your app-specific password here
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                // Optional for localhost/dev
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer'       => false,
                        'verify_peer_name'  => false,
                        'allow_self_signed' => true,
                    ]
                ];
                $mail->setFrom('akhiljose896@gmail.com', 'JobPortal');
                $mail->addAddress($toEmail);
                $mail->isHTML(true);
                $mail->Subject = 'Interview Schedule';
                $mail->Body    = "hi {$name},\n\n You are invited for an interview for the job: <strong>$jobTitle</strong>.<br><br>Please find the calendar invite attached.<br><br>📅 <strong>Date:</strong> $datetime<br>
                     🧭 <strong>Mode:</strong> {$data['mode']}<br>
                     📍 <strong>Location:</strong> {$data['location']}<br><br>
                     📝 <strong>Notes:</strong><br>{$data['notes']}";
                 $mail->addStringAttachment($ics, 'interview.ics', 'base64', 'text/calendar');

                $mail->send();
            } catch (Exception $e) {
                log_message('error', 'Mailer Error: ' . $mail->ErrorInfo);
      }
}

public function ReportJobs(){
    $jobId = $this->request->getPost('job_id');
    $reason = $this->request->getPost('reason');
   // print_r($reason);exit();

    // Save to report table or send admin email
    $db = \Config\Database::connect();
    $db->table('job_reports')->insert([
        'job_id' => $jobId,
        'user_id' => session('user_id'),
        'reason' =>  $reason,
        'created_at' => date('Y-m-d H:i:s')
    ]);

    return redirect()->back()->with('success', 'Job reported successfully.'); 
}

public function withdraw($jobId)
{
    $userId = session()->get('user_id');

    $applicationModel = new \App\Models\ApplicationModel();
    $userModel = new \App\Models\UserModel();
    $jobModel = new \App\Models\JobModel();
    $notificationModel = new \App\Models\NotificationModel();

    $application = $applicationModel
        ->where(['job_id' => $jobId, 'user_id' => $userId])
        ->first();

    if (!$application) {
        return redirect()->back()->with('error', 'Application not found.');
    }

    // Soft delete
    $applicationModel->delete($application['id']);

    // Get job and employer info
    $job = $jobModel->find($jobId);
    $user = $userModel->find($userId);
    $employer = $userModel->find($job['employer_id']);

    // Create notification for employer
    $notificationModel->save([
        'user_id' => $employer['id'],
        'job_id'  => $jobId,
        'message' => "Applicant {$user['user_name']} has withdrawn their application for '{$job['title']}'.",
        'link'    => site_url('employer/applicants/' . $jobId),
        'is_read' => 0,
        'created_at' => date('Y-m-d H:i:s')
    ]);

    // ✅ Optional: Send email to employer
    helper('email');
    //sendWithdrawEmail($employer['email'], $job['title'], $user['user_name']);

    return redirect()->to('jobs/AppliedJobs')->with('success', 'You have withdrawn your application.');
}

/*function sendWithdrawEmail($toEmail, $jobTitle, $applicantName)
{
    $email = \Config\Services::email();

    $email->setTo($toEmail);
    $email->setSubject('Job Application Withdrawn');
    $email->setMessage("Hi,\n\nThe applicant <strong>{$applicantName}</strong> has withdrawn their application for the job: <strong>{$jobTitle}</strong>.");

    return $email->send();
}*/
public function archive($jobId)
{
    if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'user') {
        return redirect()->to('auth/login')->with('error', 'Login required.');
    }

    $userId = session()->get('user_id');
    $applicationModel = new \App\Models\ApplicationModel();

    // Mark the application as archived
    $updated = $applicationModel->where([
            'user_id' => $userId,
            'job_id'  => $jobId
        ])
        ->set('is_archived', 1)
        ->update();

    if ($updated) {
        return redirect()->to('jobs/archieved')->with('success', 'Job archived successfully.');
    }

    return redirect()->back()->with('error', 'Failed to archive job.');
}

public function viewarchive()
{
   helper('text');
   $userId = session()->get('user_id');

    $applicationModel = new \App\Models\ApplicationModel();
    $jobModel = new \App\Models\JobModel();

    // Get all jobs user applied to
    $applications = $applicationModel->where('user_id', $userId)->where('is_archived',1)->findAll();
    $jobIds = array_column($applications, 'job_id');
    //print_r($jobIds);exit;

    $jobs = [];
    if (!empty($jobIds)) {
        $jobs = $jobModel->whereIn('id', $jobIds)->orderBy('created_at', 'DESC')->findAll();
        //print_r($jobs);exit;
    }

    return view('jobs/archived_jobs', ['jobs'=>$jobs]);
}
public function RestoreJob($id = null)
{
    if (!session()->get('isLoggedIn') || session()->get('user_role') !== 'user') {
        return redirect()->to('auth/login')->with('error', 'Login required.');
    }

    $jobModel = new \App\Models\JobModel();
    $job = $jobModel->find($id);

    if (!$job) {
        return redirect()->back()->with('error', 'Job not found.');
    }

    $userId = session()->get('user_id');
    $applicationModel = new \App\Models\ApplicationModel();

    // Restore archived job application
    $updated = $applicationModel->where([
            'user_id' => $userId,
            'job_id'  => $id  
        ])
        ->set('is_archived', 0)
        ->update();

    if ($updated) {
        return redirect()->to('jobs/AppliedJobs')->with('success', 'Job restored successfully.');
    }

    return redirect()->back()->with('error', 'Failed to restore job.');
}

public function ContactEmployer($jobId){
    $userId = session()->get('user_id');

    $jobModel = new \App\Models\JobModel();
    $job = $jobModel->find($jobId);

    if (!$job) {
        return redirect()->back()->with('error', 'Job not found.');
    }

    $employerId = $job['employer_id'];

    // You can also check if this user applied to this job before allowing
    $applicationModel = new \App\Models\ApplicationModel();
    $hasApplied = $applicationModel
        ->where('job_id', $jobId)
        ->where('user_id', $userId)
        ->first();

    if (!$hasApplied) {
        return redirect()->back()->with('error', 'You must apply before contacting employer.');
    }

    // Redirect or load the chat screen
   // return redirect()->to(site_url("chat/conversation/$employerId/$jobId"));
        return redirect()->to(site_url("chat/inbox/" .$jobId));

}
    public function conversation($employerId = null, $jobId = null)
    {
        $userId = session()->get('user_id');
        //$jobId = $this->request->getGet('job_id');
        //print_r( $jobId);exit();

        $messageModel = new MessageModel();
        $data['messages'] = $messageModel
            ->where("(sender_id = $userId AND receiver_id = $employerId OR sender_id = $employerId AND receiver_id = $userId)")
            ->where('job_id', $jobId)
            ->orderBy('created_at', 'ASC')
            ->findAll();

            //print_r($data['messages']);exit();

        $data['receiverId'] = $employerId;
        $data['jobId'] = $jobId;

        return view('chat/conversation', $data);
    }

    public function sendMessage()
    {
        $messageModel = new MessageModel();

        $messageModel->insert([
            'sender_id'   => session()->get('user_id'),
            'receiver_id' => $this->request->getPost('receiver_id'),
            'job_id'      => $this->request->getPost('job_id'),
            'message'     => $this->request->getPost('message'),
        ]);

        return $this->response->setJSON(['status' => 'success']);
    }

    public function fetchMessages($receiverId)
    {
        $userId = session()->get('user_id');
        $jobId = $this->request->getGet('job_id');

        $messageModel = new MessageModel();
        $messages = $messageModel
            ->where("(sender_id = $userId AND receiver_id = $receiverId OR sender_id = $receiverId AND receiver_id = $userId)")
            ->where('job_id', $jobId)
            ->orderBy('created_at', 'ASC')
            ->findAll();

        return $this->response->setJSON($messages);
    }

     public function inbox($jobId = null)
    {
       // echo "grrr";exit;
        helper('text');
        $session = session();
        $userId = $session->get('user_id'); // adjust based on your session key
       // print_r($userId);exit();

        $messageModel = new MessageModel();

        // Fetch all messages for inbox
        $data['messages'] = $messageModel
            ->where('receiver_id', $userId)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        // Count unread messages for badge
        $data['unreadCount'] = $messageModel
            ->where(['receiver_id' => $userId, 'is_read' => 0])
            ->countAllResults();


        return view('chat/inbox' .$jobId, $data);
    }

  public function viewChat($senderId)
 {
    $session = session();
    $receiverId = $session->get('user_id');

    $messageModel = new \App\Models\MessageModel();
    $userModel = new \App\Models\UserModel();

    // Fetch messages
    if (empty($senderId) || empty($receiverId)) {
    return redirect()->back()->with('error', 'Invalid chat participants.');
    }else{
    $messages = $messageModel
        ->where("(sender_id = $senderId AND receiver_id = $receiverId) OR (sender_id = $receiverId AND receiver_id = $senderId)")
        ->orderBy('id', 'ASC')
        ->findAll();
    }
    //echo $messageModel->getLastQuery(); exit;
    // Get all unique user IDs
    $userIds = array_unique(array_merge(
        array_column($messages, 'sender_id'),
        array_column($messages, 'receiver_id')
    ));

     // Prevent empty whereIn()
    $users = !empty($userIds)
        ? $userModel->whereIn('id', $userIds)->findAll()
        : [];

    $userMap = [];
    foreach ($users as $user) {
        $userMap[$user['id']] = $user['name'];
    }
     // Sender name fallback
    $senderName = $userMap[$senderId] ?? '';

     // ✅ If no messages, show empty chat view instead of error
    if (empty($messages)) {
        return view('chat/employerview', [
            'messages'   => [],
            'senderId'   => $senderId,
            'senderName' => $senderName,
            'userMap'    => []
        ]);
    }

 // Sender name fallback
    $senderName = $userMap[$senderId] ?? '';

    // Mark messages as read
    $messageModel->where([
        'sender_id'  => $senderId,
        'receiver_id'=> $receiverId,
        'is_read'    => 0
    ])->set(['is_read' => 1])->update();

    return view('chat/employerview', [
        'messages' => $messages,
        'senderId' => $senderId,
        'senderName' => $senderName,
        'userMap' => $userMap
    ]);
}

public function SendMessageToEmployee(){
    $session = session();
    $senderId = $session->get('user_id');
    $receiverId = $this->request->getPost('receiver_id');
    $message = $this->request->getPost('message');

    $messageModel = new \App\Models\MessageModel();
    $messageModel->save([
        'sender_id' => $senderId,
        'receiver_id' => $receiverId,
        'message' => $message,
        'is_read' => 0
    ]);

    return redirect()->to('chat/view/' . $receiverId);  
}

 public function ajaxMessages($senderId){
        $session = session();
        $receiverId = $session->get('user_id');

        $messageModel = new MessageModel();
        $data['messages'] = $messageModel
            ->where("(sender_id = $senderId AND receiver_id = $receiverId) OR (sender_id = $receiverId AND receiver_id = $senderId)")
            ->orderBy('created_at', 'ASC')
            ->findAll();

        return view('chat/messages_fragment', $data);
    }

}