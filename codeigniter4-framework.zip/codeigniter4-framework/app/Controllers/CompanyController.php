<?php

namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\CompanyModel;

class CompanyController extends BaseController
{
    protected $companyModel;

    public function __construct()
    {
        $this->companyModel = new CompanyModel();
    }

    public function index()
    {
        //$data['companies'] = $this->companyModel->findAll();
         $model = new \App\Models\CompanyModel();
         $data = [
        'companies' => $model->paginate(10),
        'pager' => $model->pager
    ];
        return view('admin/companies/index', $data);
    }

    public function create()
    {
        return view('admin/companies/create');
    }

    public function store()
    {
        $validation = \Config\Services::validation();
        $rules = [
            'name'     => 'required',
            'location' => 'required',
            'industry' => 'required',
            'logo'     => 'uploaded[logo]|max_size[logo,2048]|is_image[logo]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $logo = $this->request->getFile('logo');
        $logoName = $logo->getRandomName();
        $logo->move('uploads/companies', $logoName);

        $this->companyModel->save([
            'name'      => $this->request->getPost('name'),
            'location'  => $this->request->getPost('location'),
            'industry'  => $this->request->getPost('industry'),
            'job_count' => $this->request->getPost('job_count'),
            'logo'      => $logoName,
        ]);

        return redirect()->to('/admin/companies')->with('success', 'Company created successfully');
    }

    public function edit($id)
    {
        $data['company'] = $this->companyModel->find($id);
        return view('admin/companies/edit', $data);
    }

    public function update($id)
    {
        $data = $this->companyModel->find($id);
        $logo = $this->request->getFile('logo');
        $logoName = $data['logo'];

        if ($logo && $logo->isValid()) {
            $logoName = $logo->getRandomName();
            $logo->move('uploads/companies', $logoName);
        }

        $this->companyModel->update($id, [
            'name'      => $this->request->getPost('name'),
            'location'  => $this->request->getPost('location'),
            'industry'  => $this->request->getPost('industry'),
            'job_count' => $this->request->getPost('job_count'),
            'logo'      => $logoName,
        ]);

        return redirect()->to('/admin/companies')->with('success', 'Company updated successfully');
    }

    public function delete($id)
    {
        $this->companyModel->delete($id);
        return redirect()->to('/admin/companies')->with('success', 'Company deleted');
    }

    public function search()
{
    $keyword = $this->request->getGet('keyword');
    $model = new \App\Models\CompanyModel();
    $query = $model;
    if ($keyword) {
        $query = $query->like('name', $keyword)
                       ->orLike('location', $keyword)
                       ->orLike('industry', $keyword);
    }

    $data = [
        'companies' => $query->paginate(10),
        'pager' => $model->pager
    ];
     if ($this->request->isAJAX()) {
        return view('admin/companies/list_partial', $data);
    }
    return view('admin/companies/index', $data);
}
}
