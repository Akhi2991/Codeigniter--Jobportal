<?php

namespace App\Controllers;
use App\Models\JobModel;
use App\Models\JobCategoryModel;

class dashboard extends BaseController
{
    public function index($encodedId = null)
    {
    //return view('dashboard/index',$data);
      if ($encodedId) {
        $userId = base64_decode($encodedId);

        // Optional: Check if $userId matches session
        if (session()->get('user_id') != $userId) {
            return redirect()->to('auth/login')->with('error', 'Unauthorized access.');
        }

        // Continue loading dashboard
         $jobModel = new \App\Models\JobModel();

         $upcomingExpiry = $jobModel->where('employer_id', session()->get('user_id'))
                               ->where('expires_at >=', date('Y-m-d'))
                               ->where('expires_at <=', date('Y-m-d', strtotime('+3 days')))
                               ->findAll();
        

      $data=[
             'title' => 'Dashboard',
             'user'  => session()->get(),
             'expiringJobs' => $upcomingExpiry

      ];
        return view('dashboard/index',$data);
    }
        return redirect()->to('auth/login');


    }
   
}
